package edu.northeastern.cs5200;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import edu.northeastern.cs5200.daos.FinderImpl;
import edu.northeastern.cs5200.daos.UniversityImpl;
import edu.northeastern.cs5200.models.Course;
import edu.northeastern.cs5200.models.Faculty;
import edu.northeastern.cs5200.models.Person;
import edu.northeastern.cs5200.models.Section;
import edu.northeastern.cs5200.models.Student;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class testSuite {
	
	@Autowired
	UniversityImpl uniImpl;
	
	@Autowired
	FinderImpl finderImpl;

	
	@Before
	public void setUp() {
		
		 //1.Empty the database - the test suite must remove all data from the database 
		 //before running the rest of the tests
	    uniImpl.truncateDatabase();
	    
	   //2.Creates faculties - the test suite must insert the following faculties 
	  	//before running the tests in the test suite
		Faculty Alan = new Faculty("alan", "password", "Alan", "Turin", "123A", true);
		Faculty Ada = new Faculty("ada", "password", "Ada", "Lovelace", "123B", true);
		
		uniImpl.createFaculty(Alan);
		uniImpl.createFaculty(Ada);
		
		//3.Creates students - the test suite must insert the following students before 
		//running the tests in the test suite
		
		Student Alice = new Student("alice", "password", "Alice", "Wonderland", 2020, 12000);
		Student Bob = new Student("bob", "password", "Bob", "Hope", 2021, 23000);
		Student Charlie = new Student("charlie", "password", "Charlie", "Brown", 2019, 21000);
		Student Dan = new Student("dan", "password", "Dan", "Craig", 2019, 0);
		Student Edward = new Student("edward", "password", "Edward", "Scissorhands", 2022, 11000);
		Student Frank = new Student("frank", "password", "Frank", "Herbert", 2018, 0);
		Student Gregore = new Student("gregore", "password", "Gregore", "Peck", 2023, 10000);
		
		System.out.println(uniImpl);
		uniImpl.createStudent(Alice);
		uniImpl.createStudent(Bob);
		uniImpl.createStudent(Charlie);
		uniImpl.createStudent(Dan);
		uniImpl.createStudent(Edward);
		uniImpl.createStudent(Frank);
		uniImpl.createStudent(Gregore);

		//4.Create courses - the test suite must create the following courses authored 
		//by the faculty shown
		
		//Faculty Alan = (Faculty) finderImpl.findPersonByFirstname("Alan");
		Course cs1234 = new Course("CS1234", Alan);
		Course cs2345 = new Course("CS2345", Alan);
		
		//Faculty Ada = (Faculty) finderImpl.findPersonByFirstname("Ada");
		Course cs3456 = new Course("CS3456", Ada);
		Course cs4567 = new Course("CS4567", Ada);
		
		uniImpl.createCourse(cs1234);
		uniImpl.createCourse(cs2345);
		uniImpl.createCourse(cs3456);
		uniImpl.createCourse(cs4567);
		
		//5.Create sections - the test suite must insert the following sections for the
		//courses shown
		
		Section sec4321 = new Section("SEC4321", 50, cs1234);
		Section sec5432 = new Section("SEC5432", 50, cs1234);
		Section sec6543 = new Section("SEC6543", 50, cs2345);
		Section sec7654 = new Section("SEC7654", 50, cs3456);
		
		uniImpl.createSection(sec4321);
		uniImpl.createSection(sec5432);
		uniImpl.createSection(sec6543);
		uniImpl.createSection(sec7654);
		
		//6.Enroll students in sections - the test suite must enroll the following students 
		//in the sections shown
		
		/**
		Enrollment AliceSec4321 = new Enrollment(Alice, sec4321);
		Enrollment AliceSec5432 = new Enrollment(Alice, sec5432);
		Enrollment BobSec4321 = new Enrollment(Bob, sec5432);
		Enrollment CharlieSec6543 = new Enrollment(Charlie, sec6543);
		**/
		
		uniImpl.enrollStudentInSection(Alice, sec4321);
		uniImpl.enrollStudentInSection(Alice, sec5432);
		uniImpl.enrollStudentInSection(Bob, sec5432);
		uniImpl.enrollStudentInSection(Charlie, sec6543);
		
	}
	
      
      
        //1.Validates users - write a test that validates the total number of users
		@Test
		public void AvalidatesTotalNumberOfUsers() {
			List<Person> persons = (List<Person>)finderImpl.findAllUsers();
			assertEquals(9, persons.size());
		}
		
		//2.Validates faculty - write a test that validates the total number of faculty
		@Test
		public void BvalidatesTotalNumberOfFaculty() {
			List<Faculty> faculty = finderImpl.findAllFaculty();
			assertEquals(2, faculty.size());
		}
		//3.Validates students - write a test that validates the total number of students
		@Test
		public void CvalidatesTotalNumberOfStudents() {
			List<Student> students = finderImpl.findAllStudents();
			assertEquals(7, students.size());
		}
		
	
		//4.Validates courses - write a test that validates the total number of courses
		@Test
		public void DvalidatesTotalNumberOfCourses() {
			List<Course> courses = finderImpl.findAllCourses();
			assertEquals(4, courses.size());
	
		}
		
	    //5.Validates sections - write a test that validates the total number of sections
		@Test
		public void EvalidatesTotalNumberOfSections() {
			List<Section> sections = finderImpl.findAllSections();
			assertEquals(4, sections.size());
	
		}
		
		//6.Validates Course authorship - write a test that validates the total number 
		//of courses authored by each faculty
     	@Test
	    public void FvalidatesTotalNumberOfCoursesAuthoredByEachFaculty() {

     		List<Faculty> faculty = finderImpl.findAllFaculty();
     		for(Faculty fal:faculty)
     		{
		    List<Course> courses = finderImpl.findCoursesForAuthor(fal);
		    assertEquals(2, courses.size());
     		}
     	}
     	
     	
		//7.Validates Section per Course - write a test that validates the total number 
		//of sections per each course
     	@Test
     	public void GvalidatesTotalNumberOfSectionsPerEachCourse() {

     		List<Course> courses = finderImpl.findAllCourses();
     		for(Course cor:courses)
     		{
		    List<Section> sections = finderImpl.findSectionForCourse(cor);
		    if(cor.getTitle().equals("CS1234"))
		    {assertEquals(2, sections.size());}
		    else if(cor.getTitle().equals("CS2345"))
		    {assertEquals(1, sections.size());}
		    else if(cor.getTitle().equals("CS3456"))
		    {assertEquals(1, sections.size());}
		    
     		}
     	}
		
	
		//8.Validates Section enrollments - write a test that validates the total number 
		//of students in each section
     	@Test
     	public void HvalidatesTotalNumberOfStudentsInEachSection() {

     		List<Section> sections = finderImpl.findAllSections();
     		for(Section sec:sections)
     		{
		    List<Student> students = finderImpl.findStudentsInSection(sec);
		    if(sec.getTitle().equals("SEC4321"))
		         {assertEquals(1, students.size());}
		    else if(sec.getTitle().equals("SEC5432"))
		         {assertEquals(2, students.size());}
		    else if(sec.getTitle().equals("SEC6543"))
		         {assertEquals(1, students.size());}
		    
     		}
     	}
		
	
		//9.Validates student enrollments - write a test that validates the total number 
		//of sections for each student
	    @Test
 	    public void IvalidatesTotalNumberOfSectionsForEachStudent() {

     		List<Student> students = finderImpl.findAllStudents();
 		    for(Student std:students)
 		   {
	          List<Section> sections = finderImpl.findSectionsForStudent(std);
	          if(std.getFirstname().equals("Alice"))
	             {assertEquals(2, sections.size());}
	          else if(std.getFirstname().equals("Bob"))
	             {assertEquals(1, sections.size());}
	          else if(std.getFirstname().equals("Charlie"))
	              {assertEquals(1, sections.size());}
	    
 		}
 	}
	
		
		//10.Validates Section seats - write a test that validates the number of section seats
	    @Test
	    public void JvalidatesTotalNumberOfSectionSeats()
	    {
	    	List<Section> sections = finderImpl.findAllSections();
	    	for(Section sec:sections)
	    	{
	    		  if(sec.getTitle().equals("SEC4321"))
			         {assertEquals(49, sec.getSeats());
			         System.out.println(sec.getTitle()+" has "+sec.getSeats()+" seats");}
			    else if(sec.getTitle().equals("SEC5432"))
			         {assertEquals(48, sec.getSeats());
			         System.out.println(sec.getTitle()+" has "+sec.getSeats()+" seats");}
			    else if(sec.getTitle().equals("SEC6543"))
			         {assertEquals(49, sec.getSeats());
			         System.out.println(sec.getTitle()+" has "+sec.getSeats()+" seats");}
			    else if(sec.getTitle().equals("SEC7654"))
		             {assertEquals(50, sec.getSeats());
		             System.out.println(sec.getTitle()+" has "+sec.getSeats()+" seats");}
	    	}
	    	
	    }

		
	}


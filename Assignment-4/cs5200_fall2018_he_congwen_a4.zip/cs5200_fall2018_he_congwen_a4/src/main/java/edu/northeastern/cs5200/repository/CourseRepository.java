package edu.northeastern.cs5200.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import edu.northeastern.cs5200.models.Course;
import edu.northeastern.cs5200.models.Faculty;
@Repository
public interface CourseRepository
         extends CrudRepository<Course, Integer>{
	
	@Query("SELECT c FROM Course c WHERE c.title=:title")
    public Course findCourseByTitle (@Param("title") String title);
	
	@Query("SELECT c FROM Course c WHERE c.author=:author")
    public List<Course> findCourseByPerson (@Param("author") Faculty author);

}

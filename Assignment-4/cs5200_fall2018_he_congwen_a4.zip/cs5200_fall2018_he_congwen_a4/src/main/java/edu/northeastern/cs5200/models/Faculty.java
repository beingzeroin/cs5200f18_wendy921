package edu.northeastern.cs5200.models;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@DiscriminatorValue(value="faculty")
@Table(name="FACULTY")
public class Faculty extends Person{
	

	@Column(name="OFFICE")
	private String office;
	
	@Column(name="TENURED")
	private boolean tenured;
	
	@OneToMany(mappedBy="author", fetch=FetchType.EAGER)
	private Set<Course> authoredCourses;
	public void authoredCourse(Course course)
	{
		this.authoredCourses.add(course);
		if(course.getAuthor()!=this)
			course.setAuthor(this);
	}

	public void addCourse(Course course)
	{
		this.authoredCourses.add(course);
	}
	
	public void removeCourse(Course course)
	{
		this.authoredCourses.remove(course);
	}
	
	
	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	public boolean isTenured() {
		return tenured;
	}

	public void setTenured(boolean tenured) {
		this.tenured = tenured;
	}

	public Set<Course> getAuthoredCourses() {
		return authoredCourses;
	}

	public void setAuthoredCourses(Set<Course> authoredCourses) {
		this.authoredCourses = authoredCourses;
	}
	

	//constructor
	
	public Faculty(String username, String password, String firstname, String lastname) {
		super(username, password, firstname, lastname);
		authoredCourses = new HashSet<>();
	}

	public Faculty(String username, String password, String firstname, String lastname, 
			String office, boolean tenured) {
		super(username, password, firstname, lastname);
		this.office = office;
		this.tenured = tenured;
		authoredCourses = new HashSet<>();
	}


	public Faculty() {};
	
	


}

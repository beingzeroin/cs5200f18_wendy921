package edu.northeastern.cs5200.daos;

import java.util.List;

import org.springframework.data.repository.query.Param;

import edu.northeastern.cs5200.models.Course;
import edu.northeastern.cs5200.models.Faculty;
import edu.northeastern.cs5200.models.Person;
import edu.northeastern.cs5200.models.Section;
import edu.northeastern.cs5200.models.Student;

public interface FinderDao {
	
	//1.
	public List<Person> findAllUsers();
	
	//2.
	public List<Faculty> findAllFaculty();
	
	//3.
	public List<Student> findAllStudents();
	
	//4.
	public List<Course> findAllCourses();
	
	//5.
	public List<Section> findAllSections();
	
	//6.
	public List<Course> findCoursesForAuthor(Faculty faculty);
	
	//7.
	public List<Section> findSectionForCourse(Course course);
	
	//8.
	public List<Student> findStudentsInSection(Section section);
	
	//9.
	public List<Section> findSectionsForStudent(Student student);
	
	//10
	public Person findPersonByFirstname (@Param("firstname") String firstname);
	
	//11.
	public Course findCourseByTitle (@Param("title") String title);
	
	//12.
	public Section findSectionByTitle (@Param("title") String title);


}

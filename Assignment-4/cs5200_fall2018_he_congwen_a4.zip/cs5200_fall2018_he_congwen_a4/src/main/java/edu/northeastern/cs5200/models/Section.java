package edu.northeastern.cs5200.models;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;


@Entity
@Table(name="SECTION")
public class Section {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String title;
	private int seats;
	
	/**
	@ManyToMany(mappedBy="enrolledSections")
    private List<Student> enrolledStudents;
	public void enrolledStudent(Student student)
	{
		this.enrolledStudents.add(student);
		if(!student.getEnrolledSections().contains(this))
		{
			student.getEnrolledSections().add(this);
		}
	}
	**/
	
	@OneToMany(mappedBy="section", fetch = FetchType.EAGER)
	private Set<Enrollment> enrolledStudents;
	  public void enrolledStudent(Enrollment enrollment) {
	     this.enrolledStudents.add(enrollment);
	     if(enrollment.getSection()!= this)
	        enrollment.setSection(this);
	}
	  
	  
	@ManyToOne()
	private Course course;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getSeats() {
		return seats;
	}

	public void setSeats(int seats) {
		this.seats = seats;
	}

	public Set<Enrollment> getEnrolledStudents() {
		return enrolledStudents;
	}

	public void setEnrolledStudents(Set<Enrollment> enrolledStudents) {
		this.enrolledStudents = enrolledStudents;
	}
	

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
		if(!course.getCourseSections().contains(this))
		{
			course.getCourseSections().add(this);
		}
	}
	
	public void addEnrollment(Enrollment enrollment)
	{
		this.enrolledStudents.add(enrollment);
	}
	
	public void removeEnrollment(Enrollment enrollment)
	{
		this.enrolledStudents.remove(enrollment);
	}

	//constructor
	public Section(int id, String title, int seats, Course course) {
		super();
		this.id = id;
		this.title = title;
		this.seats = seats;
		this.course = course;
		
		enrolledStudents = new HashSet<>();
	}

	public Section(String title, int seats, Course course) {
		super();
		this.title = title;
		this.seats = seats;
		this.course = course;
		
		enrolledStudents = new HashSet<>();
	}

	public Section() {
		super();
	}
	
	

	
	

}

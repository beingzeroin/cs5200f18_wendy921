package edu.northeastern.cs5200.daos;


import edu.northeastern.cs5200.models.Course;
import edu.northeastern.cs5200.models.Faculty;
import edu.northeastern.cs5200.models.Section;
import edu.northeastern.cs5200.models.Student;

public interface UniversityDao {
	
	//1.removes all the data from the database. Note that you might need to remove records 
	//in a particular order
	public void truncateDatabase();
	
	//2.
	public Faculty createFaculty(Faculty faculty);
	
	//3.
	public Student createStudent(Student student);
	
	//4.
	public Course createCourse(Course course);
	
	//5.
	public Section createSection(Section section);
	
	//6.
	public Course addSectionToCourse(Section section, Course course);
	
	//7.
	public Course setAuthorForCourse(Faculty faculty, Course course);
	
	//8.enrolls a student in a section updating the number of seats available 
	//and returning true. If the current available seats is zero then the enrollment
	//is refused and method returns false
	public Boolean enrollStudentInSection(Student student, Section section);


}

package edu.northeastern.cs5200.daos;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import edu.northeastern.cs5200.models.Course;
import edu.northeastern.cs5200.models.Enrollment;
import edu.northeastern.cs5200.models.Faculty;
import edu.northeastern.cs5200.models.Person;
import edu.northeastern.cs5200.models.Section;
import edu.northeastern.cs5200.models.Student;
import edu.northeastern.cs5200.repository.CourseRepository;
import edu.northeastern.cs5200.repository.EnrollmentRepository;
import edu.northeastern.cs5200.repository.FacultyRepository;
import edu.northeastern.cs5200.repository.PersonRepository;
import edu.northeastern.cs5200.repository.SectionRepository;
import edu.northeastern.cs5200.repository.StudentRepository;

@Service
public class FinderImpl implements FinderDao {
	
	private static FinderImpl instance = null;
	private FinderImpl() {}
	public static FinderImpl getInstance()
	{
		if(instance == null)
			instance = new FinderImpl();	
		return instance;
	}
	
	@Autowired(required = true)
	private PersonRepository pr;
	@Autowired(required = true)
	private FacultyRepository fr;
	@Autowired(required = true)
	private StudentRepository sr;
	@Autowired(required = true)
	private CourseRepository cr;
	@Autowired(required = true)
	private SectionRepository secr;
	@Autowired(required = true)
	private EnrollmentRepository er;

	//1.
	public List<Person> findAllUsers()
	{
		List<Person> people = (List<Person>)pr.findAll();
				   for(Person per: people)
					   System.out.println("All person "+per.getFirstname());
				return people;
	}
	
	//2.
	public List<Faculty> findAllFaculty()
	{
		List<Faculty> faculties = (List<Faculty>)fr.findAll();
		   for(Faculty fa: faculties)
			   System.out.println("All Faculty "+fa.getFirstname());
		return faculties;
	}
	
	//3.
	public List<Student> findAllStudents()
	{
		List<Student> students = (List<Student>)sr.findAll();
		   for(Student std: students)
			   System.out.println("All Students "+std.getFirstname());
		return students;
	}
	
	//4.
	public List<Course> findAllCourses()
	{
		List<Course> courses = (List<Course>)cr.findAll();
		   for(Course cor: courses)
			   System.out.println("All Courses "+cor.getTitle());
		return courses;
	}
	
	//5.
	public List<Section> findAllSections()
	{
		List<Section> sections = (List<Section>)secr.findAll();
		   for(Section sec: sections)
			   System.out.println("All Sections "+sec.getTitle());
		return sections;
	}
	
	//6.

	public List<Course> findCoursesForAuthor(Faculty faculty)
	{
		
		List<Course> courses =cr.findCourseByPerson(faculty);
	   for(Course cor: courses)
		   System.out.println("Courses For Author "+ faculty.getFirstname()+
				   " "+cor.getTitle());
	   return courses;

	}
	
	//7.
	public List<Section> findSectionForCourse(Course course)
	{
		
		List<Section> sections = secr.findSectionByCourse(course);
		   for(Section sec: sections)
			   System.out.println("Section For Course "+course.getTitle()+
					   " "+sec.getTitle());
		return sections;
	}
	
	//8.
	public List<Student> findStudentsInSection(Section section)
	{
		List<Enrollment> enroll = er.findEnrollmentBySection(section);
		List<Student> students = new ArrayList<>();
		for(Enrollment enr:enroll)
		{	
			students.add(enr.getStudent());
		}
		
		 for(Student std: students)
		   { System.out.println("Students In Section "+section.getTitle()+
				   " "+std.getFirstname());}
		return students;
	}
	
	//9.
	public List<Section> findSectionsForStudent(Student student)
	{
		List<Enrollment> enroll = er.findEnrollmentByStudent(student);
		List<Section> sections = new ArrayList<>();
		for(Enrollment enr:enroll)
		{	
			sections.add(enr.getSection());
		}
		
		 for(Section sec: sections)
		   { System.out.println("Section "+student.getFirstname()+" In is "+sec.getTitle());}
  
		return sections;
	}
	
	//10.
	public Person findPersonByFirstname (@Param("firstname") String firstname) 
	{
		Person person = pr.findPersonByFirstname(firstname);
		return person;
	}

	//11.
	public Course findCourseByTitle (@Param("title") String title)
	{
		Course course = cr.findCourseByTitle(title);
		return course;
	}
	
	//12.
	public Section findSectionByTitle (@Param("title") String title)
	{
		Section section = secr.findSectionByTitle(title);
		return section;
	}
}

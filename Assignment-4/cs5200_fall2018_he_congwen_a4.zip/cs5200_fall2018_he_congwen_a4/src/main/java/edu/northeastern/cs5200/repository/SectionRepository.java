package edu.northeastern.cs5200.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import edu.northeastern.cs5200.models.Course;
import edu.northeastern.cs5200.models.Section;
@Repository
public interface SectionRepository 
        extends CrudRepository<Section, Integer>{
	
	@Query(value = "SELECT s FROM Section s WHERE s.title=:title")
    public Section findSectionByTitle (@Param("title") String title);
	
	@Query("SELECT s FROM Section s WHERE s.course=:course")
    public List<Section> findSectionByCourse (@Param("course") Course course);

}

package edu.northeastern.cs5200.models;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="COURSE")
public class Course {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	private String title;
	
	@ManyToOne()
	private Faculty author;
	
	@OneToMany(mappedBy="course",fetch=FetchType.EAGER)
	private Set<Section> CourseSections;
	public void CourseHasSection(Section section)
	{
		this.CourseSections.add(section);
		if(section.getCourse()!=this)
			section.setCourse(this);
	}
	
	public void addSection(Section section)
	{
		this.CourseSections.add(section);
	}
	
	public void removeSection(Section section)
	{
		this.CourseSections.remove(section);
	}
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Faculty getAuthor() {
		return author;
	}

	public void setAuthor(Faculty author) {
		this.author = author;
		if (!author.getAuthoredCourses().contains(this))
		{
			author.getAuthoredCourses().add(this);
		}
	}


	public Set<Section> getCourseSections() {
		return CourseSections;
	}


	public void setCourseSections(Set<Section> courseSections) {
		CourseSections = courseSections;
	}

	
	//constructor
	
	public Course(int id, String title, Faculty author) {
		super();
		this.id = id;
		this.title = title;
		this.author = author;
		CourseSections = new HashSet<>();
	}

	public Course(String title, Faculty author) {
		super();
		this.title = title;
		this.author = author;
		CourseSections = new HashSet<>();
	}

	public Course() {
		super();
	}
	
	
	

}

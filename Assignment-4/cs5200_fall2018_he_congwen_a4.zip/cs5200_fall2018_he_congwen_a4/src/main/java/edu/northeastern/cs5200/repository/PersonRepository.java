package edu.northeastern.cs5200.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import edu.northeastern.cs5200.models.Person;
@Repository
public interface PersonRepository 
        extends CrudRepository<Person, Integer> {
	
	@Query("SELECT p FROM Person p WHERE p.firstname=:firstname")
    public Person findPersonByFirstname (@Param("firstname") String firstname);
	

}

package edu.northeastern.cs5200.daos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.northeastern.cs5200.models.Course;
import edu.northeastern.cs5200.models.Enrollment;
import edu.northeastern.cs5200.models.Faculty;
import edu.northeastern.cs5200.models.Section;
import edu.northeastern.cs5200.models.Student;
import edu.northeastern.cs5200.repository.CourseRepository;
import edu.northeastern.cs5200.repository.EnrollmentRepository;
import edu.northeastern.cs5200.repository.FacultyRepository;
import edu.northeastern.cs5200.repository.PersonRepository;
import edu.northeastern.cs5200.repository.SectionRepository;
import edu.northeastern.cs5200.repository.StudentRepository;

@Service
public class UniversityImpl implements UniversityDao{
	
	private static UniversityImpl instance = null;
	private UniversityImpl() {}
	public static UniversityImpl getInstance()
	{
		if(instance == null)
			instance = new UniversityImpl();	
		return instance;
	}
	
	@Autowired(required = true)
	private PersonRepository pr;
	@Autowired(required = true)
	private FacultyRepository fr;
	@Autowired(required = true)
	private StudentRepository sr;
	@Autowired(required = true)
	private CourseRepository cr;
	@Autowired(required = true)
	private SectionRepository secr;
	@Autowired(required = true)
	private EnrollmentRepository er;
	
	//1.removes all the data from the database. Note that you might need to remove records 
	//in a particular order
	/**
	@Transactional
	@Modifying
	@Query(value = "truncate table enrollment; truncate table section; truncate table course;"
			+ "truncate table person;",nativeQuery = true)
			
	**/

	
	public void truncateDatabase()
	{
		er.deleteAll();
		secr.deleteAll();
		cr.deleteAll();
		sr.deleteAll();
		fr.deleteAll();
		pr.deleteAll();
		
	}
	
	//2.
	/**
	@Query(value = "insert into person(username, password, firstname, lastname, office, tenured)"
			+ " values(?1,?2,?3,?4,?5,?6);",nativeQuery = true)
   **/			

	public Faculty createFaculty(Faculty faculty)
	{
		return fr.save(faculty);
	}
	
	//3.
	public Student createStudent(Student student)
	{
		return sr.save(student);
	}
	
	//4.
	public Course createCourse(Course course)
	{
		return cr.save(course);
	}
	
	//5.
	public Section createSection(Section section)
	{
		return secr.save(section);
	}
	
	//6.
	public Course addSectionToCourse(Section section, Course course)
	{
		section.setCourse(course);
		secr.save(section);
		course.CourseHasSection(section);
		cr.save(course);
		
		return course;
	}
	
	//7.
	public Course setAuthorForCourse(Faculty faculty, Course course)
	{
		course.setAuthor(faculty);
		cr.save(course);
		faculty.authoredCourse(course);
		fr.save(faculty);
		
		return course;
	}
	
	//8.enrolls a student in a section updating the number of seats available 
	//and returning true. If the current available seats is zero then the enrollment
	//is refused and method returns false
	public Boolean enrollStudentInSection(Student student, Section section)
	{
		
		Section sec = secr.findSectionByTitle(section.getTitle());
		
		int seat = sec.getSeats();
		
		if(seat>0)
		{	
		Enrollment enrollment = new Enrollment(student, section);
		student.enrolledSection(enrollment);
		section.enrolledStudent(enrollment);
		er.save(enrollment);
		
		sec.setSeats(seat-1);
		
		secr.save(sec);
		
		return true;
		}
		
		else {
			return false;
		}
		
	}
}

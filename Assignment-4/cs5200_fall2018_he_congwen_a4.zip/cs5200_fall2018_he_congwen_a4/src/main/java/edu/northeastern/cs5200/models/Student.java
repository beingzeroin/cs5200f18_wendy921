package edu.northeastern.cs5200.models;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;


@Entity
@DiscriminatorValue(value="student")
@Table(name="STUDENT")
public class Student extends Person {
	
	

	@Column(name="GRAD_YEAR")
	private int gradYear;
	
	@Column(name="SCHOLARSHIP")
	private long scholarship;
	
	/**
	@ManyToMany
	@JoinTable(name="ENROLLMENT", joinColumns=@JoinColumn(name="STUDENT_ID", 
	referencedColumnName="ID"), inverseJoinColumns=@JoinColumn(name="SECTION_ID",
	referencedColumnName="ID"))
	
	
	private List<Section> enrolledSections;
	public void enrollSection(Section section)
	{
		this.enrolledSections.add(section);
		if(section.getEnrolledStudents().contains(this))
		{
			section.getEnrolledStudents().add(this);
		}
	}
	
	**/
	
	
	@OneToMany(mappedBy="student", fetch = FetchType.EAGER)
	private Set<Enrollment> enrolledSections;
	  public void enrolledSection(Enrollment enrollment) {
	     this.enrolledSections.add(enrollment);
	     if(enrollment.getStudent()!= this)
	        enrollment.setStudent(this);
	}


	public int getGradYear() {
		return gradYear;
	}

	public void setGradYear(int gradYear) {
		this.gradYear = gradYear;
	}

	public long getScholarship() {
		return scholarship;
	}

	public void setScholarship(long scholarship) {
		this.scholarship = scholarship;
	}

	public Set<Enrollment> getEnrolledSections() {
        	
		return enrolledSections;
	}


	public void setEnrolledSections(Set<Enrollment> enrolledSections) {
		this.enrolledSections = enrolledSections;
	}	
	
	public void addEnrollment(Enrollment enrollment)
	{
		this.enrolledSections.add(enrollment);
	}
	
	public void removeEnrollment(Enrollment enrollment)
	{
		this.enrolledSections.remove(enrollment);
	}
	
	//constructor
	
	public Student(String username, String password, String firstname, String lastname) {
		super(username, password, firstname, lastname);
		enrolledSections= new HashSet<>();	
	}


	public Student(String username, String password, String firstname, String lastname,
			int gradYear, long scholarship) {
		super(username, password, firstname, lastname);
		this.gradYear = gradYear;
		this.scholarship = scholarship;
		enrolledSections= new HashSet<>();
		
	}
	
	public Student() {};

}

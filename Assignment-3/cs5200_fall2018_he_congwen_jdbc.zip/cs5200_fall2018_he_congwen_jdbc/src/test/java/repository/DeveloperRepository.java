package repository;

import org.springframework.data.repository.CrudRepository;

import edu.northeastern.cs5200.models.Developer;


public interface DeveloperRepository extends CrudRepository<Developer, Integer>
{

}

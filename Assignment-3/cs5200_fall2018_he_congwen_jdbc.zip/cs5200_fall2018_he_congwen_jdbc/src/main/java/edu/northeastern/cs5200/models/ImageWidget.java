package edu.northeastern.cs5200.models;

public class ImageWidget extends Widget{
	

	private String src;

	
	public String getSrc() {
		return src;
	}

	public void setSrc(String src) {
		this.src = src;
	}
	
	//constructor
	public ImageWidget(int id, String name, int width, int height, String css_class, String css_style, String text,
			int order) {
		super(id, name, width, height, css_class, css_style, text, order);
		// TODO Auto-generated constructor stub
	}
	
	public ImageWidget(int id, String name, int width, int height, String css_class, String css_style, String text,
			int order, String src, Page page) {
		super(id, name, width, height, css_class, css_style, text, order, page);
		this.src = src;
	}

}

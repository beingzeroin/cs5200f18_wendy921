package edu.northeastern.cs5200.daos;

import java.util.Collection;


import edu.northeastern.cs5200.models.User;

public interface UserImpl {
	
	public void createUser(User User);
	
	/**
	public Collection<User> findAllUsers();
	
	public User findUserById(int userId);
	
	public User findUserByUsername(String username);
	
	public User findUserByCredentials(String username, String password);
	
	public int updateUser(int userId, User User);
	
	public int deleteUser(int userId);
	**/

}

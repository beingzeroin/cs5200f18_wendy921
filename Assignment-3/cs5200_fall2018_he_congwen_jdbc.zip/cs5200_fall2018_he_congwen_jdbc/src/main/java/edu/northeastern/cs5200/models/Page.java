package edu.northeastern.cs5200.models;

import java.util.Date;
import java.util.Collection;

public class Page {

	private int id;
	private String title;
	private String description;
	private Date created;
	private Date updated;
	private int views;
	private Website web;
	private Collection<Widget> wid;
	
	
	//one to many
	
	
	public Collection<Widget> getWid() {
		return wid;
	}
	public void setWid(Collection<Widget> wid) {
		this.wid = wid;
	}
	
	public boolean addWidget(Widget w)
	{
		
		boolean add_wid = wid.add(w);
		return add_wid;
	}
	
	
	public boolean removeWidget(Widget w)
	{
		boolean rev_wid = wid.remove(w);
		return rev_wid;
	}
	
	
	//////////////////////
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	
	
	public Date getUpdated() {
		return updated;
	}
	public void setUpdated(Date updated) {
		this.updated = updated;
	}
	
	
	public int getViews() {
		return views;
	}
	public void setViews(int views) {
		this.views = views;
	}
	
	
	public Website getWeb() {
		return web;
	}
	public void setWeb(Website web) {
		this.web = web;
	}



	//constructor
	public Page(int id, String title, String description, Date created, Date updated, int views)
	{
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.created = created;
		this.updated = updated;
		this.views = views;
		
	}
	public Page(int id, String title, String description, Date created, Date updated, int views,
			Website web) {
		
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.created = created;
		this.updated = updated;
		this.views = views;
		this.web = web;
		
	}


	
	
}

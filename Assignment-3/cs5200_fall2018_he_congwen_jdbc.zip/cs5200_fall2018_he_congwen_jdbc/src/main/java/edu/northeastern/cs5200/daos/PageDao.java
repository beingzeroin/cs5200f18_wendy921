package edu.northeastern.cs5200.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import edu.northeastern.cs5200.MyConnection;
import edu.northeastern.cs5200.models.Page;
import edu.northeastern.cs5200.models.Website;


public class PageDao implements PageImpl {
	
	private static PageDao instance = null;
	private PageDao() {}
	public static PageDao getInstance()
	{
		if (instance == null)
			instance = new PageDao();
		return instance;
	}
	
	

	//1. create page for website
	
	private final String CREATE_PAGE_FOR_WEBSITE = "INSERT INTO page (id, web_id," 
            + "title, description, created, updated, views) VALUES (?,?,?,?,?,?,?);";
	
	public void createPageForWebsite(int websiteId, Page page)
	{
		
		PreparedStatement preStatement = null;
		Connection conn = null;
				
	  try {
		  
		    conn = MyConnection.getConnection(); 
			preStatement = conn.prepareStatement(CREATE_PAGE_FOR_WEBSITE);
					
			preStatement.setInt(1,page.getId());
			preStatement.setInt(2,websiteId);
		    preStatement.setString(3, page.getTitle());
		    preStatement.setString(4, page.getDescription());
		    preStatement.setDate(5, (Date) page.getCreated());
		    preStatement.setDate(6, (Date) page.getUpdated());
		    preStatement.setInt(7, page.getViews());
		
		        
	        preStatement.executeUpdate();
	        
	        
       }
     catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
       finally {
	      try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
            }
}
	
	
	//2. find all pages
	
	private final String FIND_ALL_PAGE = "SELECT * FROM page;";
	
	public Collection<Page> findAllPages()
	{
        Collection<Page> pages = new ArrayList<Page>();
		
		Connection conn = null;
		Statement statement = null;
		ResultSet results = null;
		
		WebsiteDao websiteDao = WebsiteDao.getInstance();
		
		try {
			conn = MyConnection.getConnection();
			statement = conn.createStatement();
		    results = statement.executeQuery(FIND_ALL_PAGE);
		    
		    
		    while(results.next())
		    {
		    	int id = results.getInt("id");
		    	
		    	int websiteId = results.getInt("web_id");
		    	Website website = websiteDao.findWebsiteById(websiteId);
		    	
		    	String title = results.getString("title");
		    	String description = results.getString("description");
		    	Date created = results.getDate("created");
		    	Date updated = results.getDate("updated");
		    	int views = results.getInt("views");

		    	
		    	
		    	Page page = new Page(id, title, description, created, updated, views, website);
		    	pages.add(page);
		    	
		    }
		    results.close();
			statement.close();
			conn.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    
	    return pages;

	}
	 
	
	//3.find page by id
	
	private final String FIND_PAGE_BY_ID = "SELECT * FROM page WHERE id=?;";
	public Page findPageById(int pageId)
	{
		Page page = null;
		
		PreparedStatement preStatement = null;
		ResultSet results = null;
		Connection conn = null;
		WebsiteDao websiteDao = WebsiteDao.getInstance();
		
		try {
			conn = MyConnection.getConnection(); 		
		    preStatement = conn.prepareStatement(FIND_PAGE_BY_ID);
		    preStatement.setInt(1,pageId);
	        results = preStatement.executeQuery();
		
	    if(results.next())
	    {
	    	pageId = results.getInt("id");
	    	
	    	int websiteId = results.getInt("web_id");
	    	Website website = websiteDao.findWebsiteById(websiteId);
	    	
	    	String title = results.getString("title");
	    	String description = results.getString("description");
	    	Date created = results.getDate("created");
	    	Date updated = results.getDate("updated");
	    	int views = results.getInt("views");
	    	
	    	
	    	page = new Page(pageId, title, description, created, updated, views, website);
	    }
	    results.close();
		preStatement.close();
		conn.close();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	    
	    return page;
	}
	
	
	//4.find pages for website
	
	private final String FIND_PAGE_FOR_WEBSITE = "SELECT * FROM page WHERE web_id=?;";
	public Collection<Page> findPagesForWebsite(int websiteId)
	{
        Collection<Page> pages = new ArrayList<Page>();
		
        PreparedStatement preStatement = null;
		ResultSet results = null;
		Connection conn = null;
		WebsiteDao websiteDao = WebsiteDao.getInstance();
		
		
		try {
			conn = MyConnection.getConnection(); 
			preStatement = conn.prepareStatement(FIND_PAGE_FOR_WEBSITE);
		    preStatement.setInt(1,websiteId);
	        results = preStatement.executeQuery();
			
		    while(results.next())
		    {
		    int id = results.getInt("id");
		    
	    	websiteId = results.getInt("web_id");
	    	Website website = websiteDao.findWebsiteById(websiteId);
	    	
	    	String title = results.getString("title");
	    	String description = results.getString("description");
	    	Date created = results.getDate("created");
	    	Date updated = results.getDate("updated");
	    	int views = results.getInt("views");
	    	
	    	
	    	Page page = new Page(id, title, description, created, updated, views, website);
	    	pages.add(page);
	    }
	   
	    results.close();
	    preStatement.close();
	    conn.close();
	
	      }
	     catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     return pages;
	     
	}
	
	
	
	//5.update page
	private final String UPDATE_PAGE = "UPDATE page SET web_id=?, title=?,"
			+ "description=?, created=?, updated=?, views=? WHERE id=?;";
	
	public int updatePage(int pageId, Page page)
	{

		PreparedStatement preStatement = null;
		
		Connection conn = null;
				
        try {
        	 conn = MyConnection.getConnection(); 

		preStatement = conn.prepareStatement(UPDATE_PAGE);
		

		preStatement.setInt(1,page.getWeb().getId());
	    preStatement.setString(2, page.getTitle());
	    preStatement.setString(3, page.getDescription());
	    preStatement.setDate(4, (Date) page.getCreated());
	    preStatement.setDate(5, (Date) page.getUpdated());
	    preStatement.setInt(6,page.getViews());
	    
	    preStatement.setInt(7,pageId);
	    
	    preStatement.executeUpdate();
	    
	    
        preStatement.close();
       
        conn.close();
        
        return 1;
        
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			return 0;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
       
	}
	
	
	//6.delete page
	private final String DELETE_PAGE = "DELETE FROM page WHERE id=?;";
	
	public int deletePage(int pageId)
	{
		 PreparedStatement preStatement = null;
			
			Connection conn = null;
			
			try {
				conn = MyConnection.getConnection(); 		
			    preStatement = conn.prepareStatement(DELETE_PAGE);
			    preStatement.setInt(1,pageId);
		        preStatement.executeUpdate();
		        
			
	            preStatement.close();
			    conn.close();
			    
			    return 1;
		} catch (ClassNotFoundException e) 
			{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		} catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
	}

	}
	
	//7. find page by title
	private final String FIND_PAGE_BY_TITLE = "SELECT * FROM page WHERE title=?;";
	public Page findPageByTitle(String pageTitle)
	{
		 Page page = null;
			
			PreparedStatement preStatement = null;
			ResultSet results = null;
			Connection conn = null;
			WebsiteDao websiteDao = WebsiteDao.getInstance();
			
			try {
				conn = MyConnection.getConnection(); 		
			    preStatement = conn.prepareStatement(FIND_PAGE_BY_TITLE);
			    preStatement.setString(1,pageTitle);
		        results = preStatement.executeQuery();
			
		    if(results.next())
		    {
		    	int id = results.getInt("id");
		    	
		    	int websiteId = results.getInt("web_id");
		    	Website website = websiteDao.findWebsiteById(websiteId);
		    	
		    	pageTitle = results.getString("title");
		    	
		    	String description = results.getString("description");
		    	Date created = results.getDate("created");
		    	Date updated = results.getDate("updated");
		    	int views = results.getInt("views");
		    	
		    	
		    	page = new Page(id, pageTitle, description, created, updated, views, website);
		    }
		    results.close();
			preStatement.close();
			conn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		    
		    return page;
	}
	
	/////////////////////////////////////////////////////
	/**
	public static void main (String[] args)
	{   DeveloperDao developerDao = DeveloperDao.getInstance();
		Developer bob = new Developer(23, "Bob", "Marley", "bob", "bob", "bob@marley.com",
       		 null, "5432trew");
        developerDao.createDeveloper(bob);
        
        WebsiteDao websiteDao = WebsiteDao.getInstance();
        Website CNET = new Website(567, "CNET",
				 "an American media website that publishes reviews, news, articles, blogs, "
				 + "podcasts and videos on technology and consumer electronics",
				 new Date(System.currentTimeMillis()),
				 new Date(System.currentTimeMillis()), 5433455, bob);
        
        Developer developer2 = developerDao.findDeveloperByUsername("bob");
		 int developerId2 = developer2.getId();
		 websiteDao.createWebsiteForDeveloper(developerId2, CNET);
        
		PageDao pageDao = PageDao.getInstance();
		Page Home = new Page(123, "Hkkk", "Landing Page",
				 new Date(System.currentTimeMillis()),
				 new Date(System.currentTimeMillis()), 123434,CNET);
		pageDao.createPageForWebsite(567, Home);
		Home.setTitle("la");
		
		pageDao.updatePage(123, Home);
		
	}
	**/
	
}

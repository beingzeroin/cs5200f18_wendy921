package edu.northeastern.cs5200.models;

import java.sql.Date;
import java.text.ParseException;
import java.util.Collection;

public class Developer extends Person{
	
	private String developer_key;
    private Collection<Website> websites;
    
    public Collection<Website> getWebsites()
    {
    	return websites;
    }
	
	public String getDeveloper_key() {
		return developer_key;
	}

	public void setDeveloper_key(String developer_key) {
		this.developer_key = developer_key;
	}
	

	//constructor 1
	public Developer(int id, String firstname, String lastname, String developer_key) throws ParseException
	{
		super(id, firstname, lastname);
		
		this.developer_key=developer_key;
	
		
	}
	
	
	//constructor 2
	public Developer(int id, String firstname, String lastname, String username, String password, 
			String email, Date dob, String developer_key)
	{
		super(id, firstname, lastname, username, password, email, dob);
		
		this.developer_key=developer_key;
		
	}
	

	//constructor 3
	public Developer(int id, String firstname, String lastname, String username, String password, 
			String email, Date dob, 
			Collection<Phones> phones, Collection<Addresses> addresses, String developer_key)
	{
		super(id, firstname, lastname, username, password, email, dob,  phones, addresses);
		this.developer_key=developer_key;

		
	}
	
}

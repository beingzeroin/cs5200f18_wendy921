package edu.northeastern.cs5200.daos;



import java.util.Collection;

import edu.northeastern.cs5200.models.Developer;
import edu.northeastern.cs5200.models.Phones;

public interface PhoneImpl {
	
	public void createPhoneForDeveloper(Developer developer);
	
	public Collection<Phones> findPhoneForDeveloper(int developerId);
	
	public int updatePhoneForDeveloper(String username, Phones phone, boolean primary);
	
	//public int deletePhoneForDeveloper(String username, boolean primary);

}

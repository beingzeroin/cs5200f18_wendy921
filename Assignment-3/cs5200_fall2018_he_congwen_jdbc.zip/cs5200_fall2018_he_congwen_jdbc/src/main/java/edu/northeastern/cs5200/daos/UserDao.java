package edu.northeastern.cs5200.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collection;

import edu.northeastern.cs5200.MyConnection;
import edu.northeastern.cs5200.models.Developer;
import edu.northeastern.cs5200.models.User;

public class UserDao implements UserImpl{
	
	private static UserDao instance = null;
	private UserDao() {}
	public static UserDao getInstance()
	{
		if(instance == null)
			instance = new UserDao();
		return instance;
	}
	
	//1. create user
	
	private final String CREATE_User1 = "INSERT INTO person(id, firstname, lastname, username, "
			+ "password, email, dob) values (?, ?, ?, ?, ?, ?, ?);";
	
	private final String CREATE_User2 = "INSERT INTO user(id, user_agreement, approved_user,"
			+ "user_key) VALUES (?, ?, ?, ?);";
	public void createUser(User user)
	{
               Connection conn = null;
			   PreparedStatement preStatement = null;
					
		 try {
				conn = MyConnection.getConnection(); 
				
				//insert into person
				preStatement = conn.prepareStatement(CREATE_User1);
				
				preStatement.setInt(1,user.getId());
			    preStatement.setString(2, user.getFirstname());
			    preStatement.setString(3, user.getLastname());
			    preStatement.setString(4, user.getUsername());
			    preStatement.setString(5, user.getPassword());
			    preStatement.setString(6, user.getEmail());
			    preStatement.setDate(7, (Date) user.getDob());
			    
			    
		        preStatement.executeUpdate();
		        
		        //insert into user
		        preStatement = conn.prepareStatement(CREATE_User2);
		        
				preStatement.setInt(1,user.getId());
			    preStatement.setBoolean(2, user.isUser_agreement());
			    preStatement.setBoolean(3, user.isApproved_user());
			    preStatement.setString(4, user.getUser_key());
			    
			    preStatement.executeUpdate();
			    
			    preStatement.close();
			    
	        	
	        }
	       catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	       
	 finally {
		      try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 }
	}
	
		 
		 
	/**
	public Collection<User> findAllUsers();
	
	public User findUserById(int userId);
	
	public User findUserByUsername(String username);
	
	public User findUserByCredentials(String username, String password);
	
	public int updateUser(int userId, User user);
	
	public int deleteUser(int userId);
    **/
}

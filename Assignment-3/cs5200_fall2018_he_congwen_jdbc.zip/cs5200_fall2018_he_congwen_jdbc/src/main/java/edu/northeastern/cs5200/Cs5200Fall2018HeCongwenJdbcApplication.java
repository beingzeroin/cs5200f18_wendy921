package edu.northeastern.cs5200;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cs5200Fall2018HeCongwenJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(Cs5200Fall2018HeCongwenJdbcApplication.class, args);
	}
}

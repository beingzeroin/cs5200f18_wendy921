package edu.northeastern.cs5200.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import edu.northeastern.cs5200.MyConnection;
import edu.northeastern.cs5200.models.Developer;
import edu.northeastern.cs5200.models.Website;


public class WebsiteDao implements WebsiteImpl{	
	
	private static WebsiteDao instance = null;
	private WebsiteDao() {}
	public static WebsiteDao getInstance()
	{
		if(instance == null)
			instance = new WebsiteDao();
		return instance;
	}
	
	
	//1.create website for developer
	private final String CREATE_WEBSITE_FOR_DEVELOPER = "INSERT INTO website (id, developer_id,"
			+ "name, description, created, updated, visits) VALUES (?,?,?,?,?,?,?);";
    
	public void createWebsiteForDeveloper(int developerId, Website website)
	{
		
		PreparedStatement preStatement = null;
		Connection conn = null;
				
	  try {
		  
		    conn = MyConnection.getConnection(); 
			preStatement = conn.prepareStatement(CREATE_WEBSITE_FOR_DEVELOPER);
					
			preStatement.setInt(1,website.getId());
			preStatement.setInt(2,developerId);
		    preStatement.setString(3, website.getName());
		    preStatement.setString(4, website.getDescription());
		    preStatement.setDate(5, (Date) website.getCreated());
		    preStatement.setDate(6, (Date) website.getUpdated());
		    preStatement.setInt(7, website.getVisits());
		
		        
	        preStatement.executeUpdate();
	        
	        
       }
     catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
       finally {
	      try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
            }
}
      

	
	
    //2.find all website
	private final String FIND_ALL_WEBSITE = "SELECT * FROM website;";
	
	public Collection<Website> findAllWebsites()
	{
		Collection<Website> websites = new ArrayList<Website>();
		
		Connection conn = null;
		Statement statement = null;
		ResultSet results = null;
		DeveloperDao developerDao = DeveloperDao.getInstance();
		
		try {
			conn = MyConnection.getConnection();
			statement = conn.createStatement();
		    results = statement.executeQuery(FIND_ALL_WEBSITE);
		    
		    
		    while(results.next())
		    {
		    	int id = results.getInt("id");
		    	int developerId = results.getInt("developer_id");
		    	Developer developer = developerDao.findDeveloperById(developerId);
		    	String name = results.getString("name");
		    	String description = results.getString("description");
		    	Date created = results.getDate("created");
		    	Date updated = results.getDate("updated");
		    	int visits = results.getInt("visits");

		    	
		    	
		    	Website website = new Website(id, name, description, created, updated, visits, developer);
		    	websites.add(website);
		    	
		    }
		    results.close();
			statement.close();
			conn.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    
	    return websites;

	}
	
	
	//3.find websites for developer
	
	private final String FIND_WEBSITE_FOR_DEVELOPER = "SELECT * FROM website WHERE developer_id=?;";
	public Collection<Website> findWebsitesForDeveloper(int developerId)
	{
        Collection<Website> websites = new ArrayList<Website>();
		
        PreparedStatement preStatement = null;
		ResultSet results = null;
		Connection conn = null;
		DeveloperDao developerDao = DeveloperDao.getInstance();
		
		
		try {
			conn = MyConnection.getConnection(); 
			preStatement = conn.prepareStatement(FIND_WEBSITE_FOR_DEVELOPER);
		    preStatement.setInt(1,developerId);
	        results = preStatement.executeQuery();
			
		    while(results.next())
		    {
		    int id = results.getInt("id");
		    
	    	developerId = results.getInt("developer_id");
	    	Developer developer = developerDao.findDeveloperById(developerId);
	    	String name = results.getString("name");
	    	String description = results.getString("description");
	    	Date created = results.getDate("created");
	    	Date updated = results.getDate("updated");
	    	int visits = results.getInt("visits");
	    	
	   
	    	
	    	
	    	Website website = new Website(id, name, description, created, updated, visits,developer);
	    	websites.add(website);
	    }
	   
	    results.close();
	    preStatement.close();
	    conn.close();
	
	      }
	     catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     return websites;
	     
	}
		

	//4.find website by id
	
	private final String FIND_WEBSITE_BY_ID = "SELECT * FROM website WHERE id=?;";
	public Website findWebsiteById(int websiteId)
	{
		Website website = null;
		
		PreparedStatement preStatement = null;
		ResultSet results = null;
		Connection conn = null;
		DeveloperDao developerDao = DeveloperDao.getInstance();
		
		try {
			conn = MyConnection.getConnection(); 		
		    preStatement = conn.prepareStatement(FIND_WEBSITE_BY_ID);
		    preStatement.setInt(1,websiteId);
	        results = preStatement.executeQuery();
		
	    if(results.next())
	    {
	    	websiteId = results.getInt("id");
	    	
	    	int developerId = results.getInt("developer_id");
	    	Developer developer = developerDao.findDeveloperById(developerId);
	    	
	    	String name = results.getString("name");
	    	String description = results.getString("description");
	    	Date created = results.getDate("created");
	    	Date updated = results.getDate("updated");
	    	int visits = results.getInt("visits");
	    	
	    	
	    	website = new Website(websiteId, name, description, created, updated, visits,developer);
	    }
	    results.close();
		preStatement.close();
		conn.close();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	    
	    return website;
	}
	
	
	
	//5. update website
	private final String UPDATE_WEBSITE = "UPDATE website SET developer_id=?, name=?,"
			+ " description=?, created=?, updated=?, visits=? WHERE id=?;";
	
	public int updateWebsite(int websiteId, Website website)
	{
		PreparedStatement preStatement = null;

		Connection conn = null;
				
        try {
        	 conn = MyConnection.getConnection(); 
		
        
		preStatement = conn.prepareStatement(UPDATE_WEBSITE);
		
		
		
		preStatement.setInt(1,website.getDeveloper().getId());
	    preStatement.setString(2, website.getName());
	    preStatement.setString(3, website.getDescription());
	    preStatement.setDate(4, (Date) website.getCreated());
	    preStatement.setDate(5, (Date) website.getUpdated());
	    preStatement.setInt(6,website.getVisits());
	    
	    preStatement.setInt(7,websiteId);
	    
	    preStatement.executeUpdate();
	    
	    
        preStatement.close();
       
        conn.close();
        
        return 1;
        
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			return 0;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
       
	}
	
	
	
	//6.delete website
	
	private final String DELETE_WEBSITE = "DELETE FROM website  WHERE id = ?;";
	public int deleteWebsite(int websiteId)
	{
        PreparedStatement preStatement = null;
		
		Connection conn = null;
		
		try {
			conn = MyConnection.getConnection(); 		
		    preStatement = conn.prepareStatement(DELETE_WEBSITE);
		    preStatement.setInt(1,websiteId);
	        preStatement.executeUpdate();
	        
		
            preStatement.close();
		    conn.close();
		    
		    return 1;
	} catch (ClassNotFoundException e) 
		{
		// TODO Auto-generated catch block
		e.printStackTrace();
		return 0;
	} catch (SQLException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
		return 0;
	}
	}
	
	//7. find website by website name
	private final String FIND_WEBSITE_BY_NAME = "SELECT * FROM website WHERE name=?;";
	
	public Website findWebsiteByName(String websiteName)
	{
        Website website = null;
		
		PreparedStatement preStatement = null;
		ResultSet results = null;
		Connection conn = null;
		DeveloperDao developerDao = DeveloperDao.getInstance();
		
		try {
			conn = MyConnection.getConnection(); 		
		    preStatement = conn.prepareStatement(FIND_WEBSITE_BY_NAME);
		    preStatement.setString(1,websiteName);
	        results = preStatement.executeQuery();
		
	    if(results.next())
	    {
	    	int id = results.getInt("id");
	    	
	    	int developerId = results.getInt("developer_id");
	    	Developer developer = developerDao.findDeveloperById(developerId);
	    	
	    	websiteName = results.getString("name");
	    	
	    	String description = results.getString("description");
	    	Date created = results.getDate("created");
	    	Date updated = results.getDate("updated");
	    	int visits = results.getInt("visits");
	    	
	    	
	    	website = new Website(id, websiteName, description, created, updated, visits,developer);
	    }
	    results.close();
		preStatement.close();
		conn.close();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	    
	    return website;
	}

	
	
	/////////////////////////////////////////////////////
	
	/**
	public static void main (String[] args)
	{
		//WebsiteDao websiteDao = WebsiteDao.getInstance();
		
		Collection<Website> webistes = websiteDao.findAllWebsites();
		for(Website website: webistes)
		{
			System.out.println(website.getCreated());
		}
		
		
		
		Collection<Website> webistes = websiteDao.findWebsitesForDeveloper(12);
		for(Website website: webistes)
		{
			System.out.println(website.getCreated());
		}
		
	}
	**/
	
}

package edu.northeastern.cs5200.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import edu.northeastern.cs5200.MyConnection;

public class PriviledgeDao implements PriviledgeImpl{
	
	
	private static PriviledgeDao instance = null;
	private PriviledgeDao() {}
	public static PriviledgeDao getInstance()
	{
		if(instance == null)
			instance = new PriviledgeDao();
		return instance;
	}
	
	//1.assign website priviledge
	
	private final String ASSIGN_WEBISTE_PRIVILEDGE = "INSERT INTO website_priviledge"
			+ "(developer_id, web_id, priviledge) VALUES (?,?,?);";
	 public void assignWebsitePriviledge(int developerId, int websiteId, String priviledge)
	 {
			PreparedStatement preStatement = null;
			Connection conn = null;
			
					
		  try {
			  
			    conn = MyConnection.getConnection(); 
				preStatement = conn.prepareStatement(ASSIGN_WEBISTE_PRIVILEDGE);
						
				preStatement.setInt(1,developerId);
				preStatement.setInt(2,websiteId);
			    preStatement.setString(3, priviledge);
			
			
			        
		        preStatement.executeUpdate();
		        
		        
	       }
	     catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	       finally {
		      try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	            }
	}
	 
		
	 
	 //2.assign page priviledge
	 
	 private final String ASSIGN_PAGE_PRIVILEDGE = "INSERT INTO page_priviledge"
				+ "(developer_id, page_id, priviledge) VALUES (?,?,?);";
	 public void assignPagePriviledge(int developerId, int pageId, String priviledge)
	 {
		 {
				PreparedStatement preStatement = null;
				Connection conn = null;
				
						
			  try {
				  
				    conn = MyConnection.getConnection(); 
					preStatement = conn.prepareStatement(ASSIGN_PAGE_PRIVILEDGE);
							
					preStatement.setInt(1,developerId);
					preStatement.setInt(2,pageId);
				    preStatement.setString(3, priviledge);
				
				
				        
			        preStatement.executeUpdate();
			        
			        
		       }
		     catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     
		       finally {
			      try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		            }
		}
	 }
		
	 
	 //3.delete website priviledge
	 private final String DELETE_WEBSITE_PRIVILEDGE = "DELETE FROM website_priviledge WHERE "
	 		+ "developer_id=? AND web_id=? AND priviledge=?;";
	 public void deleteWebsitePriviledge(int developerId, int websiteId, String priviledge)
	 {
		 PreparedStatement preStatement = null;
			
			Connection conn = null;
			
			try {
				conn = MyConnection.getConnection(); 		
			    preStatement = conn.prepareStatement(DELETE_WEBSITE_PRIVILEDGE);
			    preStatement.setInt(1,developerId);
			    preStatement.setInt(2,websiteId);
			    preStatement.setString(3,priviledge);
		        preStatement.executeUpdate();
		        
			
	            preStatement.close();
			    conn.close();
			    
			    
		} catch (ClassNotFoundException e) 
			{
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
	 }
	
	 //4.delete page priviledge
	 private final String DELETE_PAGE_PRIVILEDGE = "DELETE FROM page_priviledge WHERE "
		 		+ "developer_id=? AND page_id=? AND priviledge=?;";
	 
	 public void deletePagePriviledge(int developerId, int pageId, String priviledge)
	 {
		 PreparedStatement preStatement = null;
			
			Connection conn = null;
			
			try {
				conn = MyConnection.getConnection(); 		
			    preStatement = conn.prepareStatement(DELETE_PAGE_PRIVILEDGE);
			    preStatement.setInt(1,developerId);
			    preStatement.setInt(2,pageId);
			    preStatement.setString(3,priviledge);
		        preStatement.executeUpdate();
		        
			
	            preStatement.close();
			    conn.close();
			    
			    
		} catch (ClassNotFoundException e) 
			{
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
	 }
	 
	 
}

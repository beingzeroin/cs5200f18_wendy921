package edu.northeastern.cs5200.models;


	
	public enum Role
	{
		owner(1,"owner"), 
		admin(2,"admin"), 
		writer(3,"writer"), 
		editor(4,"editor"), 
		reviewer(5,"reviewer");
		
		private final int key;
		private final String value;
	 
		public int getKey() {
			return key;
		}
	 
		public String getValue() {
			return value;
		}
	 
		 Role (int key, String value) {
			this.key = key;
			this.value = value;
		}
	 
        
		//get value by key
		public static String getValueByKey(int key) {
			Role[] enums = Role.values();
			for (int i = 0; i < enums.length; i++) {
				if (enums[i].getKey()== key) {
					return enums[i].getValue();
				}
			}
			return null;
		}

	}



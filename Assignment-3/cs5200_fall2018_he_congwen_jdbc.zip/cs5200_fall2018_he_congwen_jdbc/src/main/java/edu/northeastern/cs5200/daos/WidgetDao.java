package edu.northeastern.cs5200.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import edu.northeastern.cs5200.MyConnection;
import edu.northeastern.cs5200.models.HeadingWidget;
import edu.northeastern.cs5200.models.HtmlWidget;
import edu.northeastern.cs5200.models.ImageWidget;
import edu.northeastern.cs5200.models.Page;
import edu.northeastern.cs5200.models.Widget;
import edu.northeastern.cs5200.models.YoutubeWidget;


public class WidgetDao implements WidgetImpl {
	
	private static WidgetDao instance = null;
	private WidgetDao() {}
	public static WidgetDao getInstance()
	{
		if(instance == null)
			instance = new WidgetDao();
		return instance;
	}
	
	//1.create widget for page
	
	private final String CREATE_YOUTUBE_FOR_PAGE = "INSERT INTO widget (id, page_id, "
			+ "dtype, name, width, height, css_class, css_style, text, `order`, url, shareble,"
			+ "expandable) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?);";
	private final String CREATE_IMAGE_FOR_PAGE = "INSERT INTO widget (id, page_id," 
			+ "dtype, name, width, height, css_class, css_style, text, `order`, src) "
            + "VALUES (?,?,?,?,?,?,?,?,?,?,?);";
	private final String CREATE_HEADING_FOR_PAGE = "INSERT INTO widget (id, page_id," 
            + "dtype, name, width, height, css_class, css_style, text, `order`, size) " 
			+ "VALUES (?,?,?,?,?,?,?,?,?,?,?);";
	private final String CREATE_HTML_FOR_PAGE = "INSERT INTO widget (id, page_id," 
			+ "dtype, name, width, height, css_class, css_style, text, `order`, html) " 
			+ "VALUES (?,?,?,?,?,?,?,?,?,?,?);";
	
	
	public void createWidgetForPage(int pageId, Widget widget)
	{
		PreparedStatement preStatement = null;
		Connection conn = null;
		
	
	  try {

		    conn = MyConnection.getConnection(); 
		    
		    if (widget instanceof YoutubeWidget)
			{
		    	preStatement = conn.prepareStatement(CREATE_YOUTUBE_FOR_PAGE);
			
		    	String dtype = "youtube";
		    	
		    	YoutubeWidget yt = (YoutubeWidget)widget;
		    	
		    	preStatement.setInt(1,yt.getId());
				preStatement.setInt(2, pageId);
				preStatement.setString(3, dtype);
				preStatement.setString(4,yt.getName());
				preStatement.setInt(5,yt.getWidth());
				preStatement.setInt(6,yt.getHeight());
				preStatement.setString(7,yt.getCss_class());
				preStatement.setString(8,yt.getCss_style());
				preStatement.setString(9,yt.getText());
				preStatement.setInt(10,yt.getOrder());
		    	
		    	preStatement.setString(11, yt.getUrl());
		    	preStatement.setBoolean(12, yt.isShareble());
		    	preStatement.setBoolean(13, yt.isExpandable());
			}
		    
		    else if(widget instanceof ImageWidget)
		    {
		    	preStatement = conn.prepareStatement(CREATE_IMAGE_FOR_PAGE);
		    
		    	String dtype = "image";
		    	
		    	ImageWidget ima = (ImageWidget)widget;
		    	
		    	preStatement.setInt(1,ima.getId());
				preStatement.setInt(2, pageId);
				preStatement.setString(3, dtype);
				preStatement.setString(4,ima.getName());
				preStatement.setInt(5,ima.getWidth());
				preStatement.setInt(6,ima.getHeight());
				preStatement.setString(7,ima.getCss_class());
				preStatement.setString(8,ima.getCss_style());
				preStatement.setString(9,ima.getText());
				preStatement.setInt(10,ima.getOrder());

		    	preStatement.setString(11, ima.getSrc());
		    	
		    }
		    
		    else if(widget instanceof HeadingWidget)
		    {
		    	preStatement = conn.prepareStatement(CREATE_HEADING_FOR_PAGE);
		    
		    	String dtype = "heading";
		    	
		    	HeadingWidget head = (HeadingWidget)widget;
		    	
		    	preStatement.setInt(1,head.getId());
				preStatement.setInt(2, pageId);
				preStatement.setString(3, dtype);
				preStatement.setString(4,head.getName());
				preStatement.setInt(5,head.getWidth());
				preStatement.setInt(6,head.getHeight());
				preStatement.setString(7,head.getCss_class());
				preStatement.setString(8,head.getCss_style());
				preStatement.setString(9,head.getText());
				preStatement.setInt(10,head.getOrder());
				
		    	preStatement.setInt(11, head.getSize() == 0? 2:head.getSize());
	
		    }
		    
		    else if(widget instanceof HtmlWidget)
		    {
		    	preStatement = conn.prepareStatement(CREATE_HTML_FOR_PAGE);
		    	
		    	String dtype = "html";
		    	
		    	HtmlWidget ht = (HtmlWidget)widget;
		    	
		    	preStatement.setInt(1,ht.getId());
				preStatement.setInt(2, pageId);
				preStatement.setString(3, dtype);
				preStatement.setString(4,ht.getName());
				preStatement.setInt(5,ht.getWidth());
				preStatement.setInt(6,ht.getHeight());
				preStatement.setString(7,ht.getCss_class());
				preStatement.setString(8,ht.getCss_style());
				preStatement.setString(9,ht.getText());
				preStatement.setInt(10,ht.getOrder());

		    	preStatement.setString(11, ht.getHtml() );
		    	
		    }

	        preStatement.executeUpdate();
	        preStatement.close();
	        
       }
     catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
       finally {
	      try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
            }
}
	
	//////////////////////////////////////////////
		    
			
	
	/**
	private final String CREATE_WIDGET_FOR_PAGE = "INSERT INTO widget (id, page_id, "
			+ "dtype, name, width, height, css_class, css_style, text, `order`, url, shareble,"
			+ "expandable, src, size, html) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
	public void createWidgetForPage(int pageId, Widget widget)
	{
		PreparedStatement preStatement = null;
		Connection conn = null;
		
	
	  try {

		    conn = MyConnection.getConnection(); 
		    
			preStatement = conn.prepareStatement(CREATE_WIDGET_FOR_PAGE);
			
			preStatement.setInt(1,widget.getId());
			preStatement.setInt(2, pageId);
			preStatement.setString(4,widget.getName());
			preStatement.setInt(5,widget.getWidth());
			preStatement.setInt(6,widget.getHeight());
			preStatement.setString(7,widget.getCss_class());
			preStatement.setString(8,widget.getCss_style());
			preStatement.setString(9,widget.getText());
			preStatement.setInt(10,widget.getOrder());
			
			
		    if (widget instanceof YoutubeWidget)
			{
		    	String dtype = "youtube";
		    	YoutubeWidget yt = (YoutubeWidget)widget;
		    	preStatement.setString(3, dtype);
		    	preStatement.setString(11, yt.getUrl());
		    	preStatement.setBoolean(12, yt.isShareble());
		    	preStatement.setBoolean(13, yt.isExpandable());
		    
			}
					
		    else if(widget instanceof ImageWidget)
		    {
		    	String dtype = "image";
		    	ImageWidget ima = (ImageWidget)widget;
		    	preStatement.setString(3, dtype);
		    	preStatement.setString(14, ima.getSrc());
		    	
		    }
		    
		    else if(widget instanceof HeadingWidget)
		    {
		    	String dtype = "heading";
		    	HeadingWidget head = (HeadingWidget)widget;
		    	preStatement.setString(3, dtype);
		    	preStatement.setInt(15, head.getSize() == 0? 2:head.getSize());
	
		    }
		    
		    else if(widget instanceof HtmlWidget)
		    {
		    	String dtype = "html";
		    	HtmlWidget ht = (HtmlWidget)widget;
		    	preStatement.setString(3, dtype);
		    	preStatement.setString(16, ht.getHtml() );
		    	
		    }

	        preStatement.executeUpdate();
	        preStatement.close();
	        
       }
     catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
       finally {
	      try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
            }
}
      
	**/
	
	//2.find all widget
	
	private final String FIND_ALL_WIDGET = "SELECT * FROM widget;";
	public Collection<Widget> findAllWidgets()
	{
       Collection<Widget> widgets = new ArrayList<Widget>();
		
		Connection conn = null;
		Statement statement = null;
		ResultSet results = null;
		PageDao pageDao = PageDao.getInstance();
		
		try {
			conn = MyConnection.getConnection();
			statement = conn.createStatement();
		    results = statement.executeQuery(FIND_ALL_WIDGET);
		    
		    
		    while(results.next())
		    {
		    	int id = results.getInt("id");
		    	
		    	int pageId = results.getInt("page_id");
		    	Page page = pageDao.findPageById(pageId);
		    	
		    	String dtype = results.getString("dtype");
		    	

		    	String name = results.getString("name");
		    	   int width = results.getInt("width");
		      	   int height = results.getInt("height");
		    	String cssClass = results.getString("css_class");
		    	String cssStyle = results.getString("css_style");
		    	String text = results.getString("text");
		    	   int order = results.getInt("order");
		    	String url = results.getString("url");
		    	Boolean shareble = results.getBoolean("shareble");
		    	Boolean expandable = results.getBoolean("expandable");
		    	String src = results.getString("src");
		    	   int size = results.getInt("size");
		    	String htmlS = results.getString("html");

		    	
		    	if(dtype.equals("youtube"))
		    	{
		    		YoutubeWidget youtube = new YoutubeWidget(id, name, width, height,
		    				cssClass, cssStyle, text, order, url, shareble, expandable, page);
		    		widgets.add(youtube);
		    		
		    	}
		    	
		    	if(dtype.equals("image"))
		    	{
		    		ImageWidget image = new ImageWidget(id, name, width, height,
		    				cssClass, cssStyle, text, order, src, page);
		    		widgets.add(image);
		    		
		    	}
		    	
		    	if(dtype.equals("heading"))
		    	{
		    		HeadingWidget heading = new HeadingWidget(id, name, width, height,
		    				cssClass, cssStyle, text, order, size, page);
		    		widgets.add(heading);
		    		
		    	}
		    	
		    	if(dtype.equals("html"))
		    	{
		    		HtmlWidget html = new HtmlWidget(id, name, width, height,
		    				cssClass, cssStyle, text, order, htmlS, page);
		    		widgets.add(html);
		    		
		    	}
		    	
		    	
		    	
		    }
		    results.close();
			statement.close();
			conn.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    
	    return widgets;

	}
	
	
	//3.find widget by id
	private final String FIND_WIDGET_BY_ID = "SELECT * FROM widget WHERE id=?";
	
	public Widget findWidgetById(int widgetId)
	{
		
		PreparedStatement preStatement = null;
		ResultSet results = null;
		Connection conn = null;
		PageDao pageDao = PageDao.getInstance();
		
		try {
			conn = MyConnection.getConnection(); 		
		    preStatement = conn.prepareStatement(FIND_WIDGET_BY_ID);
		    preStatement.setInt(1,widgetId);
	        results = preStatement.executeQuery();
		
	    if(results.next())
	    {
	    	widgetId = results.getInt("id");
	    	
	    	int pageId = results.getInt("page_id");
	    	Page page = pageDao.findPageById(pageId);
	    	
	    	String dtype = results.getString("dtype");
	    	

	    	String name = results.getString("name");
	    	   int width = results.getInt("width");
	      	   int height = results.getInt("height");
	    	String cssClass = results.getString("css_class");
	    	String cssStyle = results.getString("css_style");
	    	String text = results.getString("text");
	    	   int order = results.getInt("order");
	    	String url = results.getString("url");
	    	Boolean shareble = results.getBoolean("shareble");
	    	Boolean expandable = results.getBoolean("expandable");
	    	String src = results.getString("src");
	    	   int size = results.getInt("size");
	    	String htmlS = results.getString("html");
	    	

	    	if(dtype.equals("youtube"))
	    	{
	    		YoutubeWidget youtube = new YoutubeWidget(widgetId, name, width, height,
	    				cssClass, cssStyle, text, order, url, shareble,expandable,page);
	    		return youtube;
	    	}
	    	
	    	if(dtype.equals("image"))
	    	{
	    		ImageWidget image = new ImageWidget(widgetId, name, width, height,
	    				cssClass, cssStyle, text, order, src, page);
	    		return image;
	    	}
	    	
	    	if(dtype.equals("heading"))
	    	{
	    		HeadingWidget heading = new HeadingWidget(widgetId, name, width, height,
	    				cssClass, cssStyle, text, order, size, page);
	    		return heading;
	    	}
	    	
	    	if(dtype.equals("html"))
	    	{
	    		HtmlWidget html = new HtmlWidget(widgetId, name, width, height,
	    				cssClass, cssStyle, text, order, htmlS, page);
	    		return html;
	    	}
	    	
	    }
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		try {
			results.close();
			preStatement.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		return null;

	}
	
	
	//4.find widget for page
	private final String FIND_WIDGET_FOR_PAGE = "SELECT * FROM widget WHERE page_id=?;";
	public Collection<Widget> findWidgetsForPage(int pageId)
	{
		 Collection<Widget> widgets = new ArrayList<Widget>();
			
	        PreparedStatement preStatement = null;
			ResultSet results = null;
			Connection conn = null;
			PageDao pageDao = PageDao.getInstance();
			
			
			try {
				conn = MyConnection.getConnection(); 
				preStatement = conn.prepareStatement(FIND_WIDGET_FOR_PAGE);
			    preStatement.setInt(1,pageId);
		        results = preStatement.executeQuery();
				
			    while(results.next())
			    {
			    	int id = results.getInt("id");
			    	
			         pageId = results.getInt("page_id");
			    	Page page = pageDao.findPageById(pageId);
			    	
			    	String dtype = results.getString("dtype");
			    	

			    	String name = results.getString("name");
			    	   int width = results.getInt("width");
			      	   int height = results.getInt("height");
			    	String cssClass = results.getString("css_class");
			    	String cssStyle = results.getString("css_style");
			    	String text = results.getString("text");
			    	   int order = results.getInt("order");
			    	String url = results.getString("url");
			    	Boolean shareble = results.getBoolean("shareble");
			    	Boolean expandable = results.getBoolean("expandable");
			    	String src = results.getString("src");
			    	   int size = results.getInt("size");
			    	String htmlS = results.getString("html");
		    	

			    	if(dtype.equals("youtube"))
			    	{
			    		YoutubeWidget youtube = new YoutubeWidget(id, name, width, height,
			    				cssClass, cssStyle, text, order, url, shareble,expandable,page);
			    		widgets.add(youtube);
			    	}
			    	
			    	if(dtype.equals("image"))
			    	{
			    		ImageWidget image = new ImageWidget(id, name, width, height,
			    				cssClass, cssStyle, text, order, src, page);
			    		widgets.add(image);
			    	}
			    	
			    	if(dtype.equals("heading"))
			    	{
			    		HeadingWidget heading = new HeadingWidget(id, name, width, height,
			    				cssClass, cssStyle, text, order, size, page);
			    		widgets.add(heading);
			    	}
			    	
			    	if(dtype.equals("html"))
			    	{
			    		HtmlWidget html = new HtmlWidget(id, name, width, height,
			    				cssClass, cssStyle, text, order, htmlS, page);
			    		widgets.add(html);
			    	}
			    	
			    	
			    	
			    }
			    results.close();
				preStatement.close();
				conn.close();
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		    
		    return widgets;

	}
	
	
	//5.update widget
/**	private final String UPDATE_WIDGET ="UPDATE widget SET page_id=?, name=?, width=?, "
			+ "height=?, css_class=?, css_style=?, text=?, `order`=?, url=?, shareble=?, expandable=?,"
			+ "src=?, size=?, html=? WHERE id=?;";
**/
	
	private final String UPDATE_YOUTUBE ="UPDATE widget SET page_id=?, name=?, width=?, "
			+ "height=?, css_class=?, css_style=?, text=?, `order`=?, url=?, shareble=?, expandable=? "
			+ "WHERE id=?;";
	
	private final String UPDATE_IMAGE ="UPDATE widget SET page_id=?, name=?, width=?, "
			+ "height=?, css_class=?, css_style=?, text=?, `order`=?,"
			+ "src=? WHERE id=?;";
	
	private final String UPDATE_HEADING ="UPDATE widget SET page_id=?, name=?, width=?, "
			+ "height=?, css_class=?, css_style=?, text=?, `order`=?,"
			+ "size=? WHERE id=?;";
	
	private final String UPDATE_HTML ="UPDATE widget SET page_id=?, name=?, width=?, "
			+ "height=?, css_class=?, css_style=?, text=?, `order`=?,"
			+ "html=? WHERE id=?;";
	
	public int updateWidget(int widgetId, Widget widget)
	{
		PreparedStatement preStatement = null;

		Connection conn = null;
				
      try {
        	 conn = MyConnection.getConnection(); 


	    if (widget instanceof YoutubeWidget)
		{
	    	preStatement = conn.prepareStatement(UPDATE_YOUTUBE);
	    	
	    	YoutubeWidget yt = (YoutubeWidget)widget;
	    	
			preStatement.setInt(1,yt.getPage().getId());
			preStatement.setString(2,yt.getName());
			preStatement.setInt(3,yt.getWidth());
			preStatement.setInt(4,yt.getHeight());
			preStatement.setString(5,yt.getCss_class());
			preStatement.setString(6,yt.getCss_style());
			preStatement.setString(7,yt.getText());
			preStatement.setInt(8,yt.getOrder());

	    	preStatement.setString(9, yt.getUrl());
	    	preStatement.setBoolean(10, yt.isShareble());
	    	preStatement.setBoolean(11, yt.isExpandable());
	    	
	    	preStatement.setInt(12,widgetId);
		}
				
	    else if(widget instanceof ImageWidget)
	    {
            preStatement = conn.prepareStatement(UPDATE_IMAGE);
	    	
            ImageWidget ima = (ImageWidget)widget;
	    	
			preStatement.setInt(1,ima.getPage().getId());
			preStatement.setString(2,ima.getName());
			preStatement.setInt(3,ima.getWidth());
			preStatement.setInt(4,ima.getHeight());
			preStatement.setString(5,ima.getCss_class());
			preStatement.setString(6,ima.getCss_style());
			preStatement.setString(7,ima.getText());
			preStatement.setInt(8,ima.getOrder());
			
	    	preStatement.setString(9, ima.getSrc());
	    	
	    	preStatement.setInt(10,widgetId);
	    	
	    }
	    
	    else if(widget instanceof HeadingWidget)
	    {
	    	preStatement = conn.prepareStatement(UPDATE_HEADING);
	    	
	    	HeadingWidget head = (HeadingWidget)widget;
	    	
	    	preStatement.setInt(1,head.getPage().getId());
			preStatement.setString(2,head.getName());
			preStatement.setInt(3,head.getWidth());
			preStatement.setInt(4,head.getHeight());
			preStatement.setString(5,head.getCss_class());
			preStatement.setString(6,head.getCss_style());
			preStatement.setString(7,head.getText());
			preStatement.setInt(8,head.getOrder());
	    
	    	preStatement.setInt(9, head.getSize() == 0? 2:head.getSize());
	    	
	    	preStatement.setInt(10,widgetId);

	    }
	    
	    else if(widget instanceof HtmlWidget)
	    {
	    	preStatement = conn.prepareStatement(UPDATE_HTML);
	    	
	    	HtmlWidget ht = (HtmlWidget)widget;
	    	
	    	preStatement.setInt(1,ht.getPage().getId());
			preStatement.setString(2,ht.getName());
			preStatement.setInt(3,ht.getWidth());
			preStatement.setInt(4,ht.getHeight());
			preStatement.setString(5,ht.getCss_class());
			preStatement.setString(6,ht.getCss_style());
			preStatement.setString(7,ht.getText());
			preStatement.setInt(8,ht.getOrder());
	    	
	    	preStatement.setString(9, ht.getHtml());
	    	
	    	preStatement.setInt(10,widgetId);
	    	
	    }
		
	    preStatement.executeUpdate();
	    
	    
        preStatement.close();
       
        conn.close();
        
        return 1;
        
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			return 0;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
	
	//6.delete widget
	private final String DELETE_WIDGET = "DELETE FROM widget WHERE id=?;";
	
	public int deleteWidget(int widgetId)
	{
		PreparedStatement preStatement = null;
		
		Connection conn = null;
		
		try {
			conn = MyConnection.getConnection(); 		
		    preStatement = conn.prepareStatement(DELETE_WIDGET);
		    preStatement.setInt(1,widgetId);
	        preStatement.executeUpdate();
	        
		
            preStatement.close();
		    conn.close();
		    
		    return 1;
	} catch (ClassNotFoundException e) 
		{
		// TODO Auto-generated catch block
		e.printStackTrace();
		return 0;
	} catch (SQLException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
		return 0;
}

	}
	
	//7.find widget by name
	private final String FIND_WIDGET_BY_NAME = "SELECT * FROM widget WHERE name=?";
	
	public Widget findWidgetByName(String widgetName)
	{
		
		PreparedStatement preStatement = null;
		ResultSet results = null;
		Connection conn = null;
		PageDao pageDao = PageDao.getInstance();
		
		try {
			conn = MyConnection.getConnection(); 		
		    preStatement = conn.prepareStatement(FIND_WIDGET_BY_NAME);
		    preStatement.setString(1,widgetName);
	        results = preStatement.executeQuery();
		
	    if(results.next())
	    {
	    	 int id = results.getInt("id");
	    	
	    	int pageId = results.getInt("page_id");
	    	Page page = pageDao.findPageById(pageId);
	    	
	    	String dtype = results.getString("dtype");
	    	

	    	widgetName = results.getString("name");
	    	   int width = results.getInt("width");
	      	   int height = results.getInt("height");
	    	String cssClass = results.getString("css_class");
	    	String cssStyle = results.getString("css_style");
	    	String text = results.getString("text");
	    	   int order = results.getInt("order");
	    	String url = results.getString("url");
	    	Boolean shareble = results.getBoolean("shareble");
	    	Boolean expandable = results.getBoolean("expandable");
	    	String src = results.getString("src");
	    	   int size = results.getInt("size");
	    	String htmlS = results.getString("html");
	    	

	    	if(dtype.equals("youtube"))
	    	{
	    		YoutubeWidget youtube = new YoutubeWidget(id, widgetName, width, height,
	    				cssClass, cssStyle, text, order, url, shareble,expandable,page);
	    		return youtube;
	    	}
	    	
	    	if(dtype.equals("image"))
	    	{
	    		ImageWidget image = new ImageWidget(id, widgetName, width, height,
	    				cssClass, cssStyle, text, order, src, page);
	    		return image;
	    	}
	    	
	    	if(dtype.equals("heading"))
	    	{
	    		HeadingWidget heading = new HeadingWidget(id,widgetName, width, height,
	    				cssClass, cssStyle, text, order, size, page);
	    		return heading;
	    	}
	    	
	    	if(dtype.equals("html"))
	    	{
	    		HtmlWidget html = new HtmlWidget(id, widgetName, width, height,
	    				cssClass, cssStyle, text, order, htmlS, page);
	    		return html;
	    	}
	    	
	    }
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		try {
			results.close();
			preStatement.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		return null;

	}
	
	/////////////////////////////////////
	/**
	public static void main(String[] args)
	
	{
		WidgetDao widgetDao = WidgetDao.getInstance();
		Widget widget = widgetDao.findWidgetByName("image345");
		
		
		
		Collection<Widget> widgets= widgetDao.findWidgetsForPage(345);
		
		for(Widget widget: widgets)
		{
	    		System.out.println("name "+ widget.getName());
	    	}
	    	
	   
		System.out.println(widget.getName());
		}
		**/
	

}

package edu.northeastern.cs5200.models;

public enum Priviledge {
	
 
	create, read, update, delete;
	

	public static void main(String[] args)
	{
		System.out.println(Priviledge.create);
	}
	

}

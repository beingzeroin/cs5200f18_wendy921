package edu.northeastern.cs5200;



import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;

import edu.northeastern.cs5200.daos.AddressDao;
import edu.northeastern.cs5200.daos.DeveloperDao;
import edu.northeastern.cs5200.daos.PageDao;
import edu.northeastern.cs5200.daos.PhoneDao;
import edu.northeastern.cs5200.daos.PriviledgeDao;
import edu.northeastern.cs5200.daos.RoleDao;
import edu.northeastern.cs5200.daos.UserDao;
import edu.northeastern.cs5200.daos.WebsiteDao;
import edu.northeastern.cs5200.daos.WidgetDao;
import edu.northeastern.cs5200.models.Addresses;
import edu.northeastern.cs5200.models.Developer;
import edu.northeastern.cs5200.models.HeadingWidget;
import edu.northeastern.cs5200.models.HtmlWidget;
import edu.northeastern.cs5200.models.ImageWidget;
import edu.northeastern.cs5200.models.Page;
import edu.northeastern.cs5200.models.Phones;
import edu.northeastern.cs5200.models.User;
import edu.northeastern.cs5200.models.Website;
import edu.northeastern.cs5200.models.Widget;
import edu.northeastern.cs5200.models.YoutubeWidget;
import edu.northeastern.cs5200.daos.StoreProcedure;

public class hw_jdbc_he_congwen {
	
	public static void main (String[] args) throws ParseException
	{
		
		DeveloperDao developerDao = DeveloperDao.getInstance();
		UserDao userDao = UserDao.getInstance();
		WebsiteDao websiteDao = WebsiteDao.getInstance();
		PageDao pageDao = PageDao.getInstance();
		WidgetDao widgetDao = WidgetDao.getInstance();
		PhoneDao phoneDao = PhoneDao.getInstance();
		AddressDao addressDao = AddressDao.getInstance();
		RoleDao roleDao = RoleDao.getInstance();
		PriviledgeDao priviledgeDao = PriviledgeDao.getInstance();
		
		
		//1.create developers
		//1.1. alice
		 Developer alice = new Developer(12, "Alice", "Wonder","alice", "alice", "alice@wonder.com",
				null, "4321rewq");
         developerDao.createDeveloper(alice);
		 
         //1.2 bob
         Developer bob = new Developer(23, "Bob", "Marley", "bob", "bob", "bob@marley.com",
        		 null, "5432trew");
         developerDao.createDeveloper(bob);
            
         //1.3 charlie
         Developer charlie = new Developer(34, "Charles", "Garcia", "charlie", "charlie", 
        		 "chuch@garcia.com", null, "6543ytre");
         developerDao.createDeveloper(charlie);
         
         /////////////////////////////////////////////////////////////////////////////////
		 
         //2. create users
         //2.1 dan
         User dan = new User(45, "Dan", "Martin", "dan", "dan", "dan@martin.com", null, false, "7654fda");
         userDao.createUser(dan);
         
         //2.2 ed
         User ed = new User(56, "Ed", "Karaz", "ed", "ed", "ed@kar.com", null, false, "5678dfgh");
         userDao.createUser(ed);
         
         /////////////////////////////////////////////////////////////////////////////////
         
         //3.create website 
         //3.1 Facebook
     	 Website Facebook = new Website(123,"Facebook",
				"an online social media and social networking service", 
				new Date(System.currentTimeMillis()),
				new Date(System.currentTimeMillis()), 1234234, alice);
     	
     	 Developer developer1 = developerDao.findDeveloperByUsername("alice");
		 int developerId1 = developer1.getId();
		 websiteDao.createWebsiteForDeveloper(developerId1, Facebook);
		
		//3.2 Twitter
		 Website Twitter = new Website(234, "Twitter",
				 "an online news and social networking service",
				 new Date(System.currentTimeMillis()),
				 new Date(System.currentTimeMillis()), 4321543, bob);
		 
		 Developer developer2 = developerDao.findDeveloperByUsername("bob");
		 int developerId2 = developer2.getId();
		 websiteDao.createWebsiteForDeveloper(developerId2, Twitter);
		 
		//3.3 Wikipedia
		 Website Wikipedia = new Website(345, "Wikipedia",
				 "a free online encyclopedia",
				 new Date(System.currentTimeMillis()),
				 new Date(System.currentTimeMillis()), 3456654, charlie);
		 
		 Developer developer3 = developerDao.findDeveloperByUsername("charlie");
		 int developerId3 = developer3.getId();
		 websiteDao.createWebsiteForDeveloper(developerId3, Wikipedia);
     	
		//3.4 CNN
		 Website CNN = new Website(456, "CNN",
				 "an American basic cable and satellite television news channel",
				 new Date(System.currentTimeMillis()),
				 new Date(System.currentTimeMillis()), 6543345, alice);

		 websiteDao.createWebsiteForDeveloper(developerId1, CNN);
		 
		//3.5 CNET
		 Website CNET = new Website(567, "CNET",
				 "an American media website that publishes reviews, news, articles, blogs, "
				 + "podcasts and videos on technology and consumer electronics",
				 new Date(System.currentTimeMillis()),
				 new Date(System.currentTimeMillis()), 5433455, bob);

		 websiteDao.createWebsiteForDeveloper(developerId2, CNET);
		 
		//3.6 Gizmodo
		 Website Gizmodo = new Website(678, "Gizmodo",
				 "a design, technology, science and science fiction website that also writes "
				 + "articles on politics",
				 new Date(System.currentTimeMillis()),
				 new Date(System.currentTimeMillis()), 4322345, charlie);

		 websiteDao.createWebsiteForDeveloper(developerId3, Gizmodo);
		 
		 /////////////////////////////////////////////////////////////////
		 
		 //4.create page
		 //4.1 home
		 Page Home = new Page(123, "Home", "Landing Page",
				 new Date(System.currentTimeMillis()),
				 new Date(System.currentTimeMillis()), 123434, CNET);
		 
		 Website website1 = websiteDao.findWebsiteByName("CNET");
		 int websiteId1 = website1.getId();
		 pageDao.createPageForWebsite(websiteId1, Home);
		 
		 //4.2 About
		 Page About = new Page(234, "About", "Website description",
				 new Date(System.currentTimeMillis()),
				 new Date(System.currentTimeMillis()), 234545, Gizmodo);
		 
		 Website website2 = websiteDao.findWebsiteByName("Gizmodo");
		 int websiteId2 = website2.getId();
		 pageDao.createPageForWebsite(websiteId2, About);
		 
		 //4.3 Contact
		 Page Contact = new Page(345, "Contact", "Addresses, phones, and contact info",
				 new Date(System.currentTimeMillis()),
				 new Date(System.currentTimeMillis()), 345656, Wikipedia);
		 
		 Website website3 = websiteDao.findWebsiteByName("Wikipedia");
		 int websiteId3 = website3.getId();
		 pageDao.createPageForWebsite(websiteId3, Contact);
		 
		 //4.4 Preferences
		 Page Preferences = new Page(456, "Preferences", "Where users can configure their preferences",
				 new Date(System.currentTimeMillis()),
				 new Date(System.currentTimeMillis()), 456776, CNN);
		 
		 Website website4 = websiteDao.findWebsiteByName("CNN");
		 int websiteId4 = website4.getId();
		 pageDao.createPageForWebsite(websiteId4, Preferences);
		 
		 //4.5 Profile
		 Page Profile = new Page(567, "Profile", "Users can configure their personal information",
				 new Date(System.currentTimeMillis()),
				 new Date(System.currentTimeMillis()), 567878, CNET);
		 
		 pageDao.createPageForWebsite(websiteId1, Profile);
		 
		 ///////////////////////////////////////////////////////////////////
		 
		 //5. create widget
		 //5.1 head123
		 HeadingWidget head123 = new HeadingWidget(123,"head123", 0, 0, "", "",
				 "Welcome", 0, 0, Home);
		 Page page1 = pageDao.findPageByTitle("Home");
		 int pageId1 = page1.getId();
		 widgetDao.createWidgetForPage(pageId1, head123);
		 
		 //5.2 post234
		 HtmlWidget post234 = new HtmlWidget(234, "post234", 0, 0, "", "",
				 "<p>Lorem</p>", 0, "", About);
		 Page page2 = pageDao.findPageByTitle("About");
		 int pageId2 = page2.getId();
		 widgetDao.createWidgetForPage(pageId2, post234);
		 
		 //5.3 head345
		 HeadingWidget head345 = new HeadingWidget(345,"head345", 0, 0, "", "",
				 "Hi", 1, 0, Contact);
		 Page page3 = pageDao.findPageByTitle("Contact");
		 int pageId3 = page3.getId();
		 widgetDao.createWidgetForPage(pageId3, head345);
		 
		 //5.4 intro456
		 HtmlWidget intro456 = new HtmlWidget(456,"intro456", 0, 0, "", "",
				 "<h1>Hi</h1>", 2, "", Contact);
		
		 widgetDao.createWidgetForPage(pageId3, intro456);
		 
		 //5.5 image345
		 ImageWidget image345 = new ImageWidget(567,"image345", 50, 100, "", "",
				 "", 3, "/img/567.png", Contact);
		
		 widgetDao.createWidgetForPage(pageId3, image345);
		 
		 //5.6 video456
		 YoutubeWidget video456 = new YoutubeWidget(678,"video456", 400, 300, "", "",
				 "", 0, "https://youtu.be/h67VX51QXiQ", false, false, Preferences);
		
		 Page page4 = pageDao.findPageByTitle("Preferences");
		 int pageId4 = page4.getId();
		 widgetDao.createWidgetForPage(pageId4, video456);
		 
		 /////////////////////////////////////////////////////////////////
		 
		 //6.create phones
         //6.1 alice phone
		 Phones alicePhone1 = new Phones("123-234-3456", true, alice);
		 alice.addPhones(alicePhone1);
		 
		 Phones alicePhone2 = new Phones("234-345-4566", false, alice);
		 alice.addPhones(alicePhone2);
		 
		 phoneDao.createPhoneForDeveloper(alice);
		 
		 //6.2 bob phone
		 Phones bobPhone1 = new Phones("345-456-5677", true, bob);
		 bob.addPhones(bobPhone1);
		 
		 phoneDao.createPhoneForDeveloper(bob);
		 
		 //6.3 charlie phone
		 Phones charliePhone1 = new Phones("321-432-5435", true, charlie);
		 charlie.addPhones(charliePhone1);
		 
		 Phones charliePhone2 = new Phones("432-432-5433", false, charlie);
		 charlie.addPhones(charliePhone2);
		 
		 Phones charliePhone3 = new Phones("543-543-6544", false, charlie);
		 charlie.addPhones(charliePhone3);
		 
		 phoneDao.createPhoneForDeveloper(charlie);
		 
		 /////////////////////////////////////////////////////////////////////////
		 
		 //7. create address
		 //7.1 alice address

		 Addresses aliceAdd1 = new Addresses("123 Adam St.", "", "Alton", "", "01234", true, alice);
		 alice.addAddresses(aliceAdd1);
		 
		 Addresses aliceAdd2 = new Addresses("234 Birch St.", "", "Boston", "", "02345", false, alice);
		 alice.addAddresses(aliceAdd2);
		 
		 addressDao.createAddressForDeveloper(alice);
		 
		 //7.2 bob address

		 Addresses bobAdd1 = new Addresses("345 Charles St.", "", "Chelms", "", "03455", true, bob);
		 bob.addAddresses(bobAdd1);
		 
		 Addresses bobAdd2 = new Addresses("456 Down St.", "", "Dalton", "", "04566", false, bob);
		 bob.addAddresses(bobAdd2);
		 
		 Addresses bobAdd3 = new Addresses("543 East St.", "", "Everett", "", "01112", false, bob);
		 bob.addAddresses(bobAdd3);
		 
		 addressDao.createAddressForDeveloper(bob);
		 
		 //7.3 charlie address

		 Addresses charlieAdd1 = new Addresses("654 Frank St.", "", "Foulton", "", "04322", true, charlie);
		 charlie.addAddresses(charlieAdd1);
		 
		 addressDao.createAddressForDeveloper(charlie);
		 
		 ///////////////////////////////////////////////////////////////////////
		
		 //8.create website role and priviledge
		 //8.1 Facebook
		 Website website5 = websiteDao.findWebsiteByName("Facebook");
		 int websiteId5 = website5.getId();
		 roleDao.assignWebsiteRole(developerId1, websiteId5, 1);
		 roleDao.assignWebsiteRole(developerId2, websiteId5, 4);
		 roleDao.assignWebsiteRole(developerId3, websiteId5, 2);
		 
		 //8.2 Twitter
		 Website website6 = websiteDao.findWebsiteByName("Twitter");
		 int websiteId6 = website6.getId();
		 roleDao.assignWebsiteRole(developerId2, websiteId6, 1);
		 roleDao.assignWebsiteRole(developerId3, websiteId6, 4);
		 roleDao.assignWebsiteRole(developerId1, websiteId6, 2);
		 
		 //8.3 Wikipedia
		 roleDao.assignWebsiteRole(developerId3, websiteId3, 1);
		 roleDao.assignWebsiteRole(developerId1, websiteId3, 4);
		 roleDao.assignWebsiteRole(developerId2, websiteId3, 2);
		 
		 //8.4 CNN
		 roleDao.assignWebsiteRole(developerId1, websiteId4, 1);
		 roleDao.assignWebsiteRole(developerId2, websiteId4, 4);
		 roleDao.assignWebsiteRole(developerId3, websiteId4, 2);
		 
		 //8.5 CNET
		 roleDao.assignWebsiteRole(developerId2, websiteId1, 1);
		 roleDao.assignWebsiteRole(developerId3, websiteId1, 4);
		 roleDao.assignWebsiteRole(developerId1, websiteId1, 2);
		 
		 //8.6 Gizmodo
		 roleDao.assignWebsiteRole(developerId3, websiteId2, 1);
		 roleDao.assignWebsiteRole(developerId1, websiteId2, 4);
		 roleDao.assignWebsiteRole(developerId2, websiteId2, 2);
		 
		 ////////////////////////////////////////////////////////////////////////
		 //9. create page role and priviledge
		 //9.1 Home
         roleDao.assignPageRole(developerId1, pageId1, 4);
         roleDao.assignPageRole(developerId2, pageId1, 5);
         roleDao.assignPageRole(developerId3, pageId1, 3);
         
		 //9.2 About
         roleDao.assignPageRole(developerId2, pageId2, 4);
         roleDao.assignPageRole(developerId3, pageId2, 5);
         roleDao.assignPageRole(developerId1, pageId2, 3);
         
		 //9.3 Contact
         roleDao.assignPageRole(developerId3, pageId3, 4);
         roleDao.assignPageRole(developerId1, pageId3, 5);
         roleDao.assignPageRole(developerId2, pageId3, 3);
         
		 //9.4 Preferences
         roleDao.assignPageRole(developerId1, pageId4, 4);
         roleDao.assignPageRole(developerId2, pageId4, 5);
         roleDao.assignPageRole(developerId3, pageId4, 3);
		 
		 //9.5 Profile
		 Page page5 = pageDao.findPageByTitle("Profile");
		 int pageId5 = page5.getId();
         
         roleDao.assignPageRole(developerId2, pageId5, 4);
         roleDao.assignPageRole(developerId3, pageId5, 5);
         roleDao.assignPageRole(developerId1, pageId5, 3);
         
         ////////////////////////////////////////////////////////////////////
         
         //11. implement updates
         //11.1 Update developer - Update Charlie's primary phone number to 333-444-5555
         Phones charlieNewPhone = new Phones("333-444-5555", true, charlie);
         phoneDao.updatePhoneForDeveloper("charlie", charlieNewPhone, true);
         
         //11.2 Update widget - Update the relative order of widget head345 on the page so that 
         //it's new order is 3. Note that the other widget's order needs to update as well
        
         Widget widget1 = widgetDao.findWidgetByName("head345");
         int pageHeadId = widget1.getPage().getId();
         
         Collection <Widget> orderWidget = widgetDao.findWidgetsForPage(pageHeadId);
         for(Widget wid : orderWidget)
         {
        	 int widId = wid.getId();
        	 wid.setOrder(((wid.getOrder()+1)%3)+1);
        	 widgetDao.updateWidget(widId, wid);
         }
         
         /**
         //(1)head345
         Widget widget1 = widgetDao.findWidgetByName("head345");
         int widgetId1 = widget1.getId();
         int wOrder1 = ((widget1.getOrder()+1)%3)+1;
         
         widget1.setOrder(wOrder1);
         widgetDao.updateWidget(widgetId1, widget1);
         
         //HeadingWidget newHead345 = new HeadingWidget(345,"head345", 0, 0, "", "",
		//		 "Hi", wOrder1, 0, Contact);
  
         //widgetDao.updateWidget(widgetId1, newHead345);

         //(2)intro456
         Widget widget2 = widgetDao.findWidgetByName("intro456");
         int widgetId2 = widget2.getId();
         int wOrder2 = ((widget2.getOrder()+1)%3)+1;
         
         widget2.setOrder(wOrder2);
         widgetDao.updateWidget(widgetId2, widget2);
         
         //HtmlWidget newIntro456 = new HtmlWidget(456,"intro456", 0, 0, "", "",
		//		 "<h1>Hi</h1>", wOrder2, "", Contact);
         
        // widgetDao.updateWidget(widgetId2, newIntro456);
         
         //(3)image345
         Widget widget3 = widgetDao.findWidgetByName("image345");
         int widgetId3 = widget3.getId();
         int wOrder3 = ((widget3.getOrder()+1)%3)+1;
         
         widget3.setOrder(wOrder3);
         widgetDao.updateWidget(widgetId3, widget3);
         
         //ImageWidget newImage345 = new ImageWidget(567,"image345", 50, 100, "", "",
		//		 "", wOrder3, "/img/567.png", Contact);
         
         //widgetDao.updateWidget(widgetId3, newImage345);
         **/
         

         //11.3 Update page - Append 'CNET - ' to the beginning of all CNET's page titles
         Collection <Page> cnetPage = pageDao.findPagesForWebsite(websiteId1);
         for(Page pa:cnetPage) {
        	 
        	 int page_id = pa.getId();
        	
        	 pa.setTitle("CNET-"+ pa.getTitle());

        	 pageDao.updatePage(page_id, pa);
        	 
         }
         
         //11.4 Update roles - Swap Charlie's and Bob's role in CNET's Home page
         int pageID = pageDao.findPageByTitle("CNET-Home").getId();
         roleDao.deletePageRole(developerId2, pageID, 5);
         roleDao.deletePageRole(developerId3, pageID, 3);
         
         roleDao.assignPageRole(developerId2, pageID, 3);
         roleDao.assignPageRole(developerId3, pageID, 5);
         
         
         //12. Implement Deletes
         //12.1 Delete developer - Delete Alice's primary address
         addressDao.deleteAddressForDeveloper("alice", true);
         
         //12.2 Delete widget - Remove the last widget in the Contact page. The last widget is 
         //the one with the highest value in the order field
         Collection <Widget> lastWidget = widgetDao.findWidgetsForPage(pageId3);
         
         int lastOr = 0;
         int lastId = 0;
         
         for(Widget w : lastWidget)
         {  
        	int or = w.getOrder();
        	
        	if (or > lastOr)
          {	
        	lastId = w.getId();
        	lastOr = or;
        	}
         }
         
         widgetDao.deleteWidget(lastId);

         //12.3 Delete page - Remove the last updated page in Wikipedia
         Collection <Page> lastPage = pageDao.findPagesForWebsite(websiteId3);
         
         Date lastUpdate = new Date(0);
         int lastPageId = 0;
         for(Page p : lastPage)
         {
        	 Date update = (Date) p.getUpdated();
        	 
        	 if(update.after(lastUpdate))
        		 {  lastUpdate = update;
        		    lastPageId = p.getId();
        		 }
         }
         
         pageDao.deletePage(lastPageId);
         
         //12.4 Delete website - Remove the CNET web site, as well as all related roles and privileges 
         //relating developers to the Website and Pages
          websiteDao.deleteWebsite(websiteId1);

          //13. store procedure
          //13.1 get_unanswered_questions
          StoreProcedure.getUnansweredQuestions ();
          
          SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");

          StoreProcedure.endorseUserForWeek (f.parse("2018-04-01"), f.parse("2018-04-10"));
        
	}
}

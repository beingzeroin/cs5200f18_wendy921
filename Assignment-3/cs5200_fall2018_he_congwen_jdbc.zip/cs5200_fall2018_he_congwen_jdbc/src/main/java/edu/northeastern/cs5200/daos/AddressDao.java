package edu.northeastern.cs5200.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import edu.northeastern.cs5200.MyConnection;
import edu.northeastern.cs5200.models.Developer;
import edu.northeastern.cs5200.models.Person;
import edu.northeastern.cs5200.models.Phones;
import edu.northeastern.cs5200.models.Addresses;



public class AddressDao implements AddressImpl{
	
	private static AddressDao instance = null;
	private AddressDao() {}
	public static AddressDao getInstance()
	{
		if(instance == null)
			instance = new AddressDao();
		return instance;
	}
	
	
	//1.create address for developer
	
	private final String INSERT_ADDRESS = "INSERT INTO address(person_id, street1, street2,"
			+ "city, state, zip, `primary`) VALUES(?,?,?,?,?,?,?);";
	public void createAddressForDeveloper(Developer developer)
	{

		   Connection conn = null;
		   PreparedStatement preStatement = null;
				
	 try {
			 conn = MyConnection.getConnection(); 
			 preStatement = conn.prepareStatement(INSERT_ADDRESS,ResultSet.TYPE_SCROLL_SENSITIVE,
	                    ResultSet.CONCUR_READ_ONLY);
			    
			    Collection<Addresses> addresses = developer.getAddresses();
			    conn.setAutoCommit(false);
			    for (Addresses a : addresses) 
			   {
			    preStatement.setInt(1,developer.getId());
			    preStatement.setString(2, a.getStreet1());
			    preStatement.setString(3, a.getStreet2());
			    preStatement.setString(4, a.getCity());
			    preStatement.setString(5, a.getState());
			    preStatement.setString(6, a.getZip());
			    preStatement.setBoolean(7, a.isPrimary());
			    
			    preStatement.addBatch();
			}
				    
				preStatement.executeBatch();
				conn.commit();
	
	            preStatement.close();
	    
 	
      }
         catch (ClassNotFoundException e) {
	      // TODO Auto-generated catch block
        	e.printStackTrace();
      } catch (SQLException e) {
     	// TODO Auto-generated catch block
	          e.printStackTrace();
      }

   finally {
   try {
		conn.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	        }

	     }
	}
	
	
	
	//2.find address for developer
	private final String FIND_ADDRESS_FOR_PERSON = "SELECT * FROM address WHERE person_id=?";
	
	public Collection<Addresses> findPhoneForDeveloper(int developerId)
	{
		Collection<Addresses> addresses = new ArrayList<Addresses>();
		
		PreparedStatement preStatement = null;
		
		ResultSet results = null;
		Connection conn = null;
		
		DeveloperDao developerDao = DeveloperDao.getInstance();
		
		try {
			conn = MyConnection.getConnection(); 		
		    preStatement = conn.prepareStatement(FIND_ADDRESS_FOR_PERSON);
		    preStatement.setInt(1,developerId);
	        results = preStatement.executeQuery();
			
		    while(results.next())
		    {		    	
		    	int id = results.getInt("id");
		    	
		    	developerId = results.getInt("person_id");
		    	Developer developer = developerDao.findDeveloperById(developerId);
		    	
		    	String street1 = results.getString("street1");
		    	String street2 = results.getString("street2");
		    	String city = results.getString("city");
		    	String state = results.getString("state");
		    	String zip = results.getString("zip");
		    	Boolean add_pri = results.getBoolean("primary");
		    	
		    	Addresses address1 = new Addresses(id, street1, street2, city, state, 
		    			zip, add_pri, developer);
		    	
		    	addresses.add(address1);
		    	
		    }
		    results.close();
			preStatement.close();
			conn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return addresses;

			}
		
		
		//
	//public int updateAddressForDeveloper(int developerId, Developer developer);
	
	
	//4. delete address for developer
	
	private final String DELETE_ADDRESS_FOR_DEVELOPER ="DELETE FROM address where person_id=? "
			+ "AND `primary`=?;";
	
	public int deleteAddressForDeveloper(String username, boolean primary)
	{
		PreparedStatement preStatement = null;

		DeveloperDao developerDao = DeveloperDao.getInstance();
		
		Connection conn = null;
				
        try {
        	
        	Developer developer = developerDao.findDeveloperByUsername(username);
        	int id = developer.getId();
        	 
        	conn = MyConnection.getConnection(); 

		  preStatement = conn.prepareStatement(DELETE_ADDRESS_FOR_DEVELOPER);
		  preStatement.setInt(1,id);
		  preStatement.setBoolean(2,primary);
	      preStatement.executeUpdate();
	    
	    
        preStatement.close();
       
        conn.close();
        
        return 1;
        
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			return 0;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
	
	/**
	public static void main(String[] args)
	{
		DeveloperDao developerDao = DeveloperDao.getInstance();
		
		
		 Developer alice = new Developer(12, "Alice", "Wonder","alice", "alice", "alice@wonder",
				null, "4321rewq");
		
		 developerDao.createDeveloper(alice);
		 
		 
		
         AddressDao addressDao = AddressDao.getInstance();
		 
		 Addresses aliceAdd = new Addresses("123 Adam St.", "", "Alton", "", "01234", true, alice);
	     alice.addAddresses(aliceAdd);
		 addressDao.createAddressForDeveloper(alice);
		
		 addressDao.deleteAddressForDeveloper("alice", aliceAdd, true);
	
	}
**/
	
}



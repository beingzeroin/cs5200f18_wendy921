package edu.northeastern.cs5200.models;

import java.sql.Date;

public class User extends Person{
	
	
    private boolean approved_user;
	private boolean user_agreement;
	private String user_key;
	
	
	public boolean isUser_agreement() {
		return user_agreement;
	}
	public void setUser_agreement(boolean user_agreement) {
		this.user_agreement = user_agreement;
	}
	
	
	public String getUser_key() {
		return user_key;
	}
	public void setUser_key(String user_key) {
		this.user_key = user_key;
	}
	
	
	public boolean isApproved_user() {
		return approved_user;
	}
	public void setApproved_user(boolean approved_user) {
		this.approved_user = approved_user;
	}

	
	//constructor
	public User(int id, String firstname, String lastname) 
	{
		super(id, firstname, lastname,"","","",null);
		
		this.approved_user = false;
	}
	
	//
	public User(int id, String firstname, String lastname, String username, String password, 
			String email, Date dob, Boolean approved_user, String user_key) 
	{
		super(id, firstname, lastname, username, password, email, dob);
		this.approved_user = false;
		this.user_key = user_key;
	}

}

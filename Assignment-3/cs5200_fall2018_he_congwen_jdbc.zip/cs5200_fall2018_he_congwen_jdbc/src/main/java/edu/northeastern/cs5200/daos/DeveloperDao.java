package edu.northeastern.cs5200.daos;

import java.util.*;
import java.sql.*;
import java.sql.Date;

import edu.northeastern.cs5200.MyConnection;
import edu.northeastern.cs5200.models.Addresses;
import edu.northeastern.cs5200.models.Developer;
import edu.northeastern.cs5200.models.Phones;




public class DeveloperDao implements DeveloperImpl{
	
	
	private static DeveloperDao instance = null;
	private DeveloperDao() {}
	public static DeveloperDao getInstance()
	{
		if(instance == null)
			instance = new DeveloperDao();
		return instance;
	}
	
	
	//1.create developer
	private final String CREATE_DEVELOPER1 = "INSERT INTO person(id, firstname, lastname, username, "
			+ "password, email, dob) values (?, ?, ?, ?, ?, ?, ?);";
	
	private final String CREATE_DEVELOPER2 = "INSERT INTO developer(id, developer_key) VALUES (?, ?);";
	
	//private final String INSERT_PHONE = "INSERT INTO phone (person_id, phone, `primary`) VALUES (?, ?, ?);";
	
	//private final String INSERT_ADDRESS = "INSERT INTO address(person_id, street1, street2,"
	//		+ "city, state, zip, primary) VALUES(?,?,?,?,?,?,?);";
	
	public void createDeveloper(Developer developer)
	{
		   Connection conn = null;
		   PreparedStatement preStatement = null;
				
	 try {
			conn = MyConnection.getConnection(); 
			
			//insert into person
			preStatement = conn.prepareStatement(CREATE_DEVELOPER1);
			
			preStatement.setInt(1,developer.getId());
		    preStatement.setString(2, developer.getFirstname());
		    preStatement.setString(3, developer.getLastname());
		    preStatement.setString(4, developer.getUsername());
		    preStatement.setString(5, developer.getPassword());
		    preStatement.setString(6, developer.getEmail());
		    preStatement.setDate(7, (Date) developer.getDob());
		    
		    
	        preStatement.executeUpdate();
	        
	        //insert into developer
	        preStatement = conn.prepareStatement(CREATE_DEVELOPER2);
	        
			preStatement.setInt(1,developer.getId());
		    preStatement.setString(2, developer.getDeveloper_key());
		    
		    preStatement.executeUpdate();
		    
		   /**
	       //insert into phone
		    preStatement = conn.prepareStatement(INSERT_PHONE,ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
		   
		    Collection<Phones> phones = developer.getPhones();
		    conn.setAutoCommit(false);
		    for (Phones p : phones) 
		   {
		    
		    preStatement.setInt(1,developer.getId());
		    preStatement.setString(2, p.getPhone());
		    
		    preStatement.setBoolean(3,p.isPrimary());
		    
		    preStatement.addBatch();
		   }
		    
		    preStatement.executeBatch();
		    conn.commit();
		    
		    
		    //insert into address
		    preStatement = conn.prepareStatement(INSERT_ADDRESS,ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
		    
		    Collection<Addresses> addresses = developer.getAddresses();
		    conn.setAutoCommit(false);
		    for (Addresses a : addresses) 
		   {
		    preStatement.setInt(1,developer.getId());
		    preStatement.setString(2, a.getStreet1());
		    preStatement.setString(3, a.getStreet2());
		    preStatement.setString(4, a.getCity());
		    preStatement.setString(5, a.getState());
		    preStatement.setString(6, a.getZip());
		    preStatement.setBoolean(7, a.isPrimary());
		    
		    preStatement.addBatch();
		     }
		    
		    preStatement.executeBatch();
		    conn.commit();
		    **/
		    preStatement.close();
		    
	        	
	        }
	       catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	       
	 finally {
		      try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 }
	}
	        
	
	
	
	//2.find all developers
	private final String FIND_ALL_DEVELOPERS = "SELECT person.id, firstname, lastname, username,"
			+ "`password`, email, dob, developer_key "
			+ "FROM person JOIN developer ON person.id = developer.id";
	private final String FIND_PHONE_FOR_PERSON = "SELECT * FROM phone WHERE person_id=?";
	private final String FIND_ADDRESS_FOR_PERSON = "SELECT * FROM address WHERE person_id=?";
	
	/**
	private final String FIND_ALL_DEVELOPERS = "SELECT person.id, firstname, lastname, username," 
            + "`password`, email, dob, developer_key FROM person, developer "
            + "WHERE person.id = developer.id;";
			
	**/
	
	public Collection<Developer> findAllDevelopers()
	{
		Collection<Developer> developers = new ArrayList<Developer>();
		
		
		Statement statement = null;
		ResultSet results = null;
		Connection conn = null;
		PreparedStatement preStatement = null;
		try {
			conn = MyConnection.getConnection(); 
			statement = conn.createStatement();
		    results = statement.executeQuery(FIND_ALL_DEVELOPERS);
			
		    while(results.next())
		    {
		    	
		    	int id = results.getInt("id");
		    	String firstname = results.getString("firstname");
		    	String lastname = results.getString("lastname");
		    	String username = results.getString("username");
		    	String password = results.getString("password");
		    	String email = results.getString("email");
		    	Date dob = results.getDate("dob");		 
		    	String developer_key = results.getString("developer_key");
		    	
			    Developer developer = new Developer(id, firstname, lastname, username, password, email,
                        dob, null, null, developer_key);
			    
	
		    	//phone
		    	Collection<Phones> phones = new ArrayList<Phones>();
		    	
		    	ResultSet PhoneResults = null;
		    	preStatement = conn.prepareStatement(FIND_PHONE_FOR_PERSON);
			    preStatement.setInt(1,id);
			    PhoneResults = preStatement.executeQuery();

			    while(PhoneResults.next())
			    {		    	
			    	int phoneId = results.getInt("id");
			    	
			    	//developerId = results.getInt("person_id");
			    	//Developer developer = developerDao.findDeveloperById(developerId);
			    	
			    	String phone = PhoneResults.getString("phone");
			    	Boolean phone_pri = PhoneResults.getBoolean("primary");
			    	
			    	Phones phone1 = new Phones(phoneId, phone, phone_pri, developer);
			    	
			    	phones.add(phone1);
			    	
			    }
			    
			
                //address
			    Collection<Addresses> addresses = new ArrayList<Addresses>();

				ResultSet AddressResults = null;
				preStatement = conn.prepareStatement(FIND_ADDRESS_FOR_PERSON);
				preStatement.setInt(1,id);
			    AddressResults = preStatement.executeQuery();
			    while(AddressResults.next())
			    {
			    	
			    	int AddressId = AddressResults.getInt("id");
			    	
			    	String street1 = AddressResults.getString("street1");
			    	String street2 = AddressResults.getString("street2");
			    	String city = AddressResults.getString("city");
			    	String state = AddressResults.getString("state");
			    	String zip = AddressResults.getString("zip");
			    	Boolean add_pri = AddressResults.getBoolean("primary");
			    	
			    	Addresses address1 = new Addresses(AddressId, street1, street2, city, state, 
			    			zip, add_pri, developer);
			    	
			    	addresses.add(address1);

			    }
		    	
			    developer.setPhones(phones);
			    developer.setAddresses(addresses);
		    	developers.add(developer);
		    }
		    results.close();
			statement.close();
			conn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    
	    return developers;

	}
	
	
	//3.find developer by id
	private final String FIND_DEVELOPER_BY_ID = "SELECT person.id, firstname, lastname, username," 
	                  + "`password`, email, dob, developer_key FROM person, developer "
	                  + "WHERE person.id = developer.id AND developer.id=?";
	
	public Developer findDeveloperById(int developerId)
	{
			Developer developer = null;
			
			PreparedStatement preStatement = null;
			ResultSet results = null;
			Connection conn = null;
			
			try {
				conn = MyConnection.getConnection(); 		
			    preStatement = conn.prepareStatement(FIND_DEVELOPER_BY_ID);
			    preStatement.setInt(1,developerId);
		        results = preStatement.executeQuery();
		        
		    if(results.next())
		    {
		    	developerId = results.getInt("id");
		    	
		    	String firstname = results.getString("firstname");
		    	String lastname = results.getString("lastname");
		    	String username = results.getString("username");
		    	String password = results.getString("password");
		    	String email = results.getString("email");
		    	Date dob = results.getDate("dob");
		    	String developer_key = results.getString("developer_key");
		    	
		    	developer = new Developer(developerId, firstname, lastname, username, password, email,
	                        dob, null, null, developer_key);
		    	 
		    	//phone
		    	Collection<Phones> phones = new ArrayList<Phones>();
		    	
		    	ResultSet PhoneResults = null;
		    	preStatement = conn.prepareStatement(FIND_PHONE_FOR_PERSON);
			    preStatement.setInt(1,developerId);
			    PhoneResults = preStatement.executeQuery();

			    while(PhoneResults.next())
			    {		    	
			    	int phoneId = results.getInt("id");
			    	
			    	String phone = PhoneResults.getString("phone");
			    	Boolean phone_pri = PhoneResults.getBoolean("primary");
			    	
			    	Phones phone1 = new Phones(phoneId, phone, phone_pri, developer);
			    	
			    	phones.add(phone1);
			    	
			    }
			    

		    	//address
			    Collection<Addresses> addresses = new ArrayList<Addresses>();

				ResultSet AddressResults = null;
				preStatement = conn.prepareStatement(FIND_ADDRESS_FOR_PERSON);
				preStatement.setInt(1,developerId);
			    AddressResults = preStatement.executeQuery();
			    while(AddressResults.next())
			    {
			    	
			    	int AddressId = AddressResults.getInt("id");
			    	
			    	String street1 = AddressResults.getString("street1");
			    	String street2 = AddressResults.getString("street2");
			    	String city = AddressResults.getString("city");
			    	String state = AddressResults.getString("state");
			    	String zip = AddressResults.getString("zip");
			    	Boolean add_pri = AddressResults.getBoolean("primary");
			    	
			    	Addresses address1 = new Addresses(AddressId, street1, street2, city, state, 
			    			zip, add_pri, developer);
			    	
			    	addresses.add(address1);

			    }
		    	
			    developer.setPhones(phones);
			    developer.setAddresses(addresses);

		    	
		    }
		    results.close();
		    preStatement.close();
			conn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		    
		    return developer;
		}
		
	
	
	//4.find developer by username
	private final String FIND_DEVELOPER_BY_USERNAME =  "SELECT person.id, firstname, lastname, username," 
            + "`password`, email, dob, developer_key FROM person, developer "
            + "WHERE person.id = developer.id AND username=?";
	public Developer findDeveloperByUsername(String username)
	{
			Developer developer = null;
			
			PreparedStatement preStatement = null;
			ResultSet results = null;
			Connection conn = null;
			
			try {
				conn = MyConnection.getConnection(); 	
			    preStatement = conn.prepareStatement(FIND_DEVELOPER_BY_USERNAME);
			    preStatement.setString(1,username);
		        results = preStatement.executeQuery();
			
		    if(results.next())
		    {
		    	username = results.getString("username");
		    	
		    	int id = results.getInt("id");
		    	String firstname = results.getString("firstname");
		    	String lastname = results.getString("lastname");
		    	String password = results.getString("password");
		    	String email = results.getString("email");
		    	Date dob = results.getDate("dob");
		    	String developer_key = results.getString("developer_key");
		    	
		    	
		    	developer = new Developer(id, firstname, lastname, username, password, email,
	                        dob, null, null, developer_key);
		    	 
		    	//phone
		    	Collection<Phones> phones = new ArrayList<Phones>();
		    	
		    	ResultSet PhoneResults = null;
		    	preStatement = conn.prepareStatement(FIND_PHONE_FOR_PERSON);
			    preStatement.setInt(1,id);
			    PhoneResults = preStatement.executeQuery();

			    while(PhoneResults.next())
			    {		    	
			    	int phoneId = results.getInt("id");
			    	
			    	String phone = PhoneResults.getString("phone");
			    	Boolean phone_pri = PhoneResults.getBoolean("primary");
			    	
			    	Phones phone1 = new Phones(phoneId, phone, phone_pri, developer);
			    	
			    	phones.add(phone1);
			    	
			    }
			    

		    	//address
			    Collection<Addresses> addresses = new ArrayList<Addresses>();

				ResultSet AddressResults = null;
				preStatement = conn.prepareStatement(FIND_ADDRESS_FOR_PERSON);
				preStatement.setInt(1,id);
			    AddressResults = preStatement.executeQuery();
			    while(AddressResults.next())
			    {
			    	
			    	int AddressId = AddressResults.getInt("id");
			    	
			    	String street1 = AddressResults.getString("street1");
			    	String street2 = AddressResults.getString("street2");
			    	String city = AddressResults.getString("city");
			    	String state = AddressResults.getString("state");
			    	String zip = AddressResults.getString("zip");
			    	Boolean add_pri = AddressResults.getBoolean("primary");
			    	
			    	Addresses address1 = new Addresses(AddressId, street1, street2, city, state, 
			    			zip, add_pri, developer);
			    	
			    	addresses.add(address1);

			    }
		    	
			    developer.setPhones(phones);
			    developer.setAddresses(addresses);
		    	

		    }
		    results.close();
			preStatement.close();
			conn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		    
		    return developer;
		}
		
	
	
	//5.find developer by credentials
	private final String FIND_DEVELOPER_BY_CREDENTIAL =  "SELECT person.id, firstname, lastname, username," 
            + "`password`, email, dob, developer_key FROM person, developer "
            + "WHERE person.id = developer.id AND username=? AND `password`=?";
	
	public Developer findDeveloperByCredentials(String username, String password)
	{
		Developer developer = null;
		
		PreparedStatement preStatement = null;
		ResultSet results = null;
		Connection conn = null;
		
		try {
			conn = MyConnection.getConnection(); 	
		    preStatement = conn.prepareStatement(FIND_DEVELOPER_BY_CREDENTIAL);
		    preStatement.setString(1,username);
		    preStatement.setString(2,password);
	        results = preStatement.executeQuery();
		
	    if(results.next())
	    {
	    	username = results.getString("username");
	        password = results.getString("password");
	        
	    	int id = results.getInt("id");
	    	String firstname = results.getString("firstname");
	    	String lastname = results.getString("lastname");	    	
	    	String email = results.getString("email");
	    	Date dob = results.getDate("dob");
	    	String developer_key = results.getString("developer_key");
	    	
	    	
	    	developer = new Developer(id, firstname, lastname, username, password, email,
                        dob, null, null, developer_key);
	    	 
	    	//phone
	    	Collection<Phones> phones = new ArrayList<Phones>();
	    	
	    	ResultSet PhoneResults = null;
	    	preStatement = conn.prepareStatement(FIND_PHONE_FOR_PERSON);
		    preStatement.setInt(1,id);
		    PhoneResults = preStatement.executeQuery();

		    while(PhoneResults.next())
		    {		    	
		    	int phoneId = results.getInt("id");
		    	
		    	String phone = PhoneResults.getString("phone");
		    	Boolean phone_pri = PhoneResults.getBoolean("primary");
		    	
		    	Phones phone1 = new Phones(phoneId, phone, phone_pri, developer);
		    	
		    	phones.add(phone1);
		    	
		    }
		    

	    	//address
		    Collection<Addresses> addresses = new ArrayList<Addresses>();

			ResultSet AddressResults = null;
			preStatement = conn.prepareStatement(FIND_ADDRESS_FOR_PERSON);
			preStatement.setInt(1,id);
		    AddressResults = preStatement.executeQuery();
		    while(AddressResults.next())
		    {
		    	
		    	int AddressId = AddressResults.getInt("id");
		    	
		    	String street1 = AddressResults.getString("street1");
		    	String street2 = AddressResults.getString("street2");
		    	String city = AddressResults.getString("city");
		    	String state = AddressResults.getString("state");
		    	String zip = AddressResults.getString("zip");
		    	Boolean add_pri = AddressResults.getBoolean("primary");
		    	
		    	Addresses address1 = new Addresses(AddressId, street1, street2, city, state, 
		    			zip, add_pri, developer);
		    	
		    	addresses.add(address1);

		    }
	    	
		    developer.setPhones(phones);
		    developer.setAddresses(addresses);
		    
	    }
	    results.close();
		preStatement.close();
		conn.close();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	    
	    return developer;
	}
	
	
	
	//6.update developer
	private final String UPDATE_DEVELOPER1= "UPDATE person SET firstname=?, lastname=?, username=?,"
			+ "password=?, email=?, dob=? WHERE id = ?";	
	
	private final String UPDATE_DEVELOPER2= "UPDATE developer SET developer_key=? WHERE id=?";
	
	//private final String UPDATE_PHONE= "UPDATE phone SET phone=?, primary=? WHERE person_id=?";
	
	//private final String UPDATE_ADDRESS= "UPDATE address SET street1=?, street2=?, city=?,"
	//		+ "state=?, zip=?, primary=? WHERE person_id=?";
	
	public int updateDeveloper(int developerId, Developer developer)
	{
		PreparedStatement preStatement = null;

		Connection conn = null;
				
        try {
        	conn = MyConnection.getConnection(); 
		
        //update person
		preStatement = conn.prepareStatement(UPDATE_DEVELOPER1);
		
	    preStatement.setString(1, developer.getFirstname());
	    preStatement.setString(2, developer.getLastname());
	    preStatement.setString(3, developer.getUsername());
	    preStatement.setString(4, developer.getPassword());
	    preStatement.setString(5, developer.getEmail());
	    preStatement.setDate(6, (Date) developer.getDob());
	    preStatement.setInt(7, developerId);
	    
	    preStatement.executeUpdate();
	    
	    //update developer
	    preStatement = conn.prepareStatement(UPDATE_DEVELOPER2);
	    
	    preStatement.setString(1, developer.getDeveloper_key());
	    preStatement.setInt(2, developerId);
	    
	    preStatement.executeUpdate();
	    
	    /**
	    //update phone  remove add
	    preStatement = conn.prepareStatement(UPDATE_PHONE);
	    preStatement.setString(1, developer.getPhones());
	    preStatement.setBoolean(2, );
	    preStatement.setInt(3, developer.getId());
	    
	    preStatement.executeUpdate();
	    
	    //update address
	    preStatement = conn.prepareStatement(UPDATE_ADDRESS);
	    preStatement.setArray(8, (Array) developer.getAddresses());
	    preStatement.setInt(7, developer.getId());
	    
	    preStatement.executeUpdate();
	    
	    **/
	    
        preStatement.close();
       
        conn.close();
        
        return 1;
        
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			return 0;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
       
	
	}
	
	
	
	
	//7.delete developer
	private final String DELETE_DEVELOPER1 = "DELETE FROM person  WHERE id = ?";	
	
	//private final String DELETE_DEVELOPER2 = "DELETE FROM developer  WHERE id = ?";
	public int deleteDeveloper(int developerId)
	{	
		PreparedStatement preStatement = null;
		
		Connection conn = null;
		
		try {
			conn = MyConnection.getConnection(); 		
		    preStatement = conn.prepareStatement(DELETE_DEVELOPER1);
		    preStatement.setInt(1,developerId);
	        preStatement.executeUpdate();
	        
	        /**
	        preStatement = conn.prepareStatement(DELETE_DEVELOPER2);
		    preStatement.setInt(1,developerId);
	        preStatement.executeUpdate();
		    **/
		
            preStatement.close();
		    conn.close();
		    
		    return 1;
	} catch (ClassNotFoundException e) 
		{
		// TODO Auto-generated catch block
		e.printStackTrace();
		return 0;
	} catch (SQLException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
		return 0;
	}
	}
	
	
	/**
	public static void main (String[] args)
	{
		DeveloperDao developerDao = DeveloperDao.getInstance();
		//Collection<Developer> developers = developerDao.findAllDevelopers();
		
		Developer developer = developerDao.findDeveloperByCredentials("alice", "alice");
		
		for(Phones p : developer.getPhones()) {
    		System.out.println("phone "+p.getPhone());
    	
    	
		for(Developer developer: developers)
		{
		  	for(Phones p : developer.getPhones()) {
	    		System.out.println("phone "+p.getPhone());
	    	}
		}
		
		
	}

	}	
	
	**/
	
	
}
	    
	
	




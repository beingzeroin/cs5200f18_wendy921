package edu.northeastern.cs5200.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import edu.northeastern.cs5200.MyConnection;
import edu.northeastern.cs5200.models.Developer;
import edu.northeastern.cs5200.models.Phones;

public class PhoneDao implements PhoneImpl {
	
	
	private static PhoneDao instance = null;
	private PhoneDao() {}
	public static PhoneDao getInstance()
	{
		if(instance == null)
			instance = new PhoneDao();
		return instance;
	}
	
	
    //1. create phone for developer
	private final String INSERT_PHONE = "INSERT INTO phone (person_id, phone, `primary`) VALUES (?, ?, ?);";
	
	public void createPhoneForDeveloper(Developer developer)
	{
		   Connection conn = null;
		   PreparedStatement preStatement = null;
				
	 try {
			conn = MyConnection.getConnection(); 
			
			preStatement = conn.prepareStatement(INSERT_PHONE,ResultSet.TYPE_SCROLL_SENSITIVE,
		    ResultSet.CONCUR_READ_ONLY);
				   
		    Collection<Phones> phones = developer.getPhones();
			conn.setAutoCommit(false);
			for (Phones p : phones) 
			{
				preStatement.setInt(1,developer.getId());
			    preStatement.setString(2, p.getPhone());
				    
				preStatement.setBoolean(3,p.isPrimary());
				    
				preStatement.addBatch();
			}
				    
				preStatement.executeBatch();
				conn.commit();
	
	    preStatement.close();
	    
    	
    }
      catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
    } catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
     }
   
      finally {
      try {
		conn.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
   }
}
	
	//2.find phone for developer
	private final String FIND_PHONE_FOR_PERSON = "SELECT * FROM phone WHERE person_id=?";
	
	public Collection<Phones> findPhoneForDeveloper(int developerId)
	{
		Collection<Phones> phones = new ArrayList<Phones>();
		
		PreparedStatement preStatement = null;
		
		ResultSet results = null;
		Connection conn = null;
		
		DeveloperDao developerDao = DeveloperDao.getInstance();
		
		try {
			conn = MyConnection.getConnection(); 		
		    preStatement = conn.prepareStatement(FIND_PHONE_FOR_PERSON);
		    preStatement.setInt(1,developerId);
	        results = preStatement.executeQuery();
		    
		    while(results.next())
		    {		    	
		    	int id = results.getInt("id");
		    	
		    	developerId = results.getInt("person_id");
		    	Developer developer = developerDao.findDeveloperById(developerId);
		    	
		    	String phone = results.getString("phone");
		    	Boolean phone_pri = results.getBoolean("primary");
		    	
		    	Phones phone1 = new Phones(id, phone, phone_pri, developer);
		    	
		    	phones.add(phone1);
		    	
		    }
		    results.close();
			preStatement.close();
			conn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return phones;

		}

	
	//3.update phone for developer
    private final String UPDATE_PHONE_FOR_DEVELOPER = "UPDATE phone SET phone=?, `primary`=?"
    		+ " WHERE person_id=? AND `primary`=? ";

	public int updatePhoneForDeveloper(String username, Phones phone, boolean primary)
	{
		PreparedStatement preStatement = null;

		DeveloperDao developerDao = DeveloperDao.getInstance();
		
		Connection conn = null;
				
        try {
        	
        	Developer developer = developerDao.findDeveloperByUsername(username);
        	int id = developer.getId();
        	 
        	conn = MyConnection.getConnection(); 

		  preStatement = conn.prepareStatement(UPDATE_PHONE_FOR_DEVELOPER);

		preStatement.setString(1,phone.getPhone()); 
	    preStatement.setBoolean(2,phone.isPrimary());
	    preStatement.setInt(3,id );
	    preStatement.setBoolean(4,primary);
	    
	    
	    preStatement.executeUpdate();
	    
	    
        preStatement.close();
       
        conn.close();
        
        return 1;
        
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			return 0;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
	
	//4.delete phone for developer
	//public int deletePhoneForDeveloper(String username, boolean primary);
	
	
	
	
	////////////////////////////////////////////////////////////////
	/**
	public static void main(String[] args)
	{
		DeveloperDao developerDao = DeveloperDao.getInstance();
		
		
		 Developer alice = new Developer(12, "Alice", "Wonder","alice", "alice", "alice@wonder",
				null, "4321rewq");
		
		 developerDao.createDeveloper(alice);
		 
		 
		 
		 PhoneDao phoneDao = PhoneDao.getInstance();
		 
		 Phones alicePhone = new Phones("123-345-3456", true, alice);
		 alice.addPhones(alicePhone);
		 
		 phoneDao.createPhoneForDeveloper(alice);
		
		Phones newPhone = new Phones("666-666-8888", true, alice);
		phoneDao.updatePhoneForDeveloper("alice",newPhone,true);
	}

	**/

}

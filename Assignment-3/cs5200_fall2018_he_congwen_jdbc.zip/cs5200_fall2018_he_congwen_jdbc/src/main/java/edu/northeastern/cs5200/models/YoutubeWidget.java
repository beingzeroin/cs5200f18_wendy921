package edu.northeastern.cs5200.models;

public class YoutubeWidget extends Widget{



	
	private String url;
	private boolean shareble;
	private boolean expandable;
	
	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	
	public boolean isShareble() {
		return shareble;
	}
	public void setShareble(boolean shareble) {
		this.shareble = shareble;
	}
	
	
	public boolean isExpandable() {
		return expandable;
	}
	public void setExpandable(boolean expandable) {
		this.expandable = expandable;
	}
	
	
	//constructor
	
	public YoutubeWidget(int id, String name, int width, int height, String css_class, String css_style, String text,
			int order) {
		super(id, name, width, height, css_class, css_style, text, order);
		// TODO Auto-generated constructor stub
	}
	
	public YoutubeWidget(int id, String name, int width, int height, String css_class, String css_style, String text,
			int order, String url, Boolean shareble, Boolean expandable,Page page) {
		
		super(id, name, width, height, css_class, css_style, text, order, page);
		this.url = url;
		this.shareble = shareble;
		this.expandable = expandable;
		
	}
	
}

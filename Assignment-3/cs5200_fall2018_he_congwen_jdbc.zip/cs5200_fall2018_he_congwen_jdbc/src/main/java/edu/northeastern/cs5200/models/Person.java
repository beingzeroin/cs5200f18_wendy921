package edu.northeastern.cs5200.models;



import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.sql.Date;



public class Person {
	
	private int id;
	private String firstname;
	private String lastname;
	private String username;
	private String password;
	private String email;
	private Date dob;
	private Collection<Phones> phones;
	private Collection<Addresses> addresses;
	
	//one to many
	public Collection<Phones> getPhones()
	{
		return phones;
	}
	
	public void setPhones(Collection<Phones> phones) {
		this.phones = phones;
	}

	
	public Collection<Addresses> getAddresses()
	{
		return addresses;
	}
	
	public void setAddresses(Collection<Addresses> addresses) {
		this.addresses = addresses;
	}

	
	public boolean addPhones(Phones p)
	{
		
		 boolean add_phone = phones.add(p);
		 return add_phone;
		
	}
	
	
	public boolean removePhones(Phones p)
	{
		boolean rev_phone = phones.remove(p);
		return rev_phone;
	}
	
	
	public boolean addAddresses(Addresses a)
	{
		boolean add_address = addresses.add(a);
		return add_address;
	}
	
	public boolean removeAddresses(Addresses a)
	{
		  boolean rev_address = addresses.remove(a);
		  return rev_address;
	}
	
	
	///////////////////
	public int getId() 
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}
	

	public String getFirstname() 
	{
		return firstname;
	}

	public void setFirstname(String firstname) 
	{
		this.firstname = firstname;
	}
	

	public String getLastname() 
	{
		return lastname;
	}

	public void setLastname(String lastname) 
	{
		this.lastname = lastname;
	}
	

	public String getUsername() 
	{
		return username;
	}

	public void setUsername(String username) 
	{
		this.username = username;
	}
	

	public String getPassword() 
	{
		return password;
	}

	public void setPassword(String password) 
	{
		this.password = password;
	}

	
	public String getEmail() 
	{
		return email;
	}

	public void setEmail(String email) 
	{
		this.email = email;
	}

	
	public Date getDob() 
	{
		return dob;
	}

	public void setDob(Date dob) 
	{
		this.dob = dob;
	}

	
	
	//constructor 1
	public Person(int id, String firstname, String lastname) throws ParseException
	{
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = "Lily";
		this.password = "123456";
		this.email = "hello@gmail.com";
		this.dob = new Date(0);
		
		Addresses defaultAdd = new Addresses("123 Adam St.", "", "Alton", "", "01234", true);
	    addresses.add(defaultAdd);
	    
	    Phones defaultPhone = new Phones("321-432-5435", true);
	    phones.add(defaultPhone);
	    
	    
		/**
		 String bd = "1999-09-09";
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		 this.dob = (Date) sdf.parse(bd);
       **/

	}
	
	//constructor 2
	public Person(int id, String firstname, String lastname, String username, String password, 
			String email, Date dob)
	{
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = username;
		this.password = password;
		this.email = email;
		this.dob = dob;
	    phones = new ArrayList<>();
	    addresses = new ArrayList<>();
	}
	
    //constructor 3
	public Person(int id, String firstname, String lastname, String username, String password, 
			String email, Date dob, Collection<Phones> phones, Collection<Addresses> addresses)
	{
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = username;
		this.password = password;
		this.email = email;
		this.dob = dob;
		this.phones = phones;
		this.addresses = addresses;
	}

	//
	public Person() {
		// TODO Auto-generated constructor stub
	}

}

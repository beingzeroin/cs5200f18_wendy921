package edu.northeastern.cs5200.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import edu.northeastern.cs5200.MyConnection;
import edu.northeastern.cs5200.models.Priviledge;
import edu.northeastern.cs5200.models.Role;

public class RoleDao implements RoleImpl {
	
	private static RoleDao instance = null;
	private RoleDao() {}
	public static RoleDao getInstance()
	{
		if(instance == null)
			instance = new RoleDao();
		return instance;
	}
	
	
	//1.assign website role
	private final String ASSIGN_WEBISTE_ROLE= "INSERT INTO website_role"
			+ "(developer_id, web_id, role) VALUES (?,?,?);";
	public void assignWebsiteRole(int developerId, int websiteId, int roleId)
	{
		PreparedStatement preStatement = null;
		Connection conn = null;
		PriviledgeDao priviledgeDao = PriviledgeDao.getInstance();
				
	  try {
            conn = MyConnection.getConnection(); 
			preStatement = conn.prepareStatement(ASSIGN_WEBISTE_ROLE);
					
			preStatement.setInt(1,developerId);
			preStatement.setInt(2,websiteId);
		    preStatement.setString(3, Role.getValueByKey(roleId));
		    preStatement.executeUpdate();
		    conn.close();
		    
		    if (roleId == 1)
		    {
		    	priviledgeDao.assignWebsitePriviledge(developerId, websiteId, Priviledge.create.toString());
		    	priviledgeDao.assignWebsitePriviledge(developerId, websiteId, Priviledge.read.toString());
		    	priviledgeDao.assignWebsitePriviledge(developerId, websiteId, Priviledge.update.toString());
		    	priviledgeDao.assignWebsitePriviledge(developerId, websiteId, Priviledge.delete.toString());
		    }
		    
		    if (roleId == 2)
		    {
		    	priviledgeDao.assignWebsitePriviledge(developerId, websiteId, Priviledge.create.toString());
		    	priviledgeDao.assignWebsitePriviledge(developerId, websiteId, Priviledge.read.toString());
		    	priviledgeDao.assignWebsitePriviledge(developerId, websiteId, Priviledge.update.toString());
		    	priviledgeDao.assignWebsitePriviledge(developerId, websiteId, Priviledge.delete.toString());
		    }
		    
		    if (roleId == 3)
		    {
		    	priviledgeDao.assignWebsitePriviledge(developerId, websiteId, Priviledge.create.toString());
		    	priviledgeDao.assignWebsitePriviledge(developerId, websiteId, Priviledge.read.toString());
		    	priviledgeDao.assignWebsitePriviledge(developerId, websiteId, Priviledge.update.toString());
		   
		    }
		    
		    if (roleId == 4)
		    {
		    	priviledgeDao.assignWebsitePriviledge(developerId, websiteId, Priviledge.create.toString());
		    	priviledgeDao.assignWebsitePriviledge(developerId, websiteId, Priviledge.read.toString());
		    }
		    
		    if (roleId == 5)
		    {
		    	priviledgeDao.assignWebsitePriviledge(developerId, websiteId, Priviledge.read.toString());
		    }
   
       }
     catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}
 
	
	
	//2.assign page role
	
	private final String ASSIGN_PAGE_ROLE= "INSERT INTO page_role"
			+ "(developer_id, page_id, role) VALUES (?,?,?);";
	public void assignPageRole(int developerId, int pageId, int roleId)
	{
		PreparedStatement preStatement = null;
		Connection conn = null;
		PriviledgeDao priviledgeDao = PriviledgeDao.getInstance();
				
	  try {
            conn = MyConnection.getConnection(); 
			preStatement = conn.prepareStatement(ASSIGN_PAGE_ROLE);
					
			preStatement.setInt(1,developerId);
			preStatement.setInt(2,pageId);
		    preStatement.setString(3, Role.getValueByKey(roleId));
		    preStatement.executeUpdate();
		    preStatement.close();
		    conn.close();
		    
		    if (roleId == 1)
		    {
		    	priviledgeDao.assignPagePriviledge(developerId, pageId, Priviledge.create.toString());
		    	priviledgeDao.assignPagePriviledge(developerId, pageId, Priviledge.read.toString());
		    	priviledgeDao.assignPagePriviledge(developerId, pageId, Priviledge.update.toString());
		    	priviledgeDao.assignPagePriviledge(developerId, pageId, Priviledge.delete.toString());
		    }
		    
		    if (roleId == 2)
		    {
		    	priviledgeDao.assignPagePriviledge(developerId, pageId, Priviledge.create.toString());
		    	priviledgeDao.assignPagePriviledge(developerId, pageId, Priviledge.read.toString());
		    	priviledgeDao.assignPagePriviledge(developerId, pageId, Priviledge.update.toString());
		    	priviledgeDao.assignPagePriviledge(developerId, pageId, Priviledge.delete.toString());
		    }
		    
		    if (roleId == 3)
		    {
		    	priviledgeDao.assignPagePriviledge(developerId, pageId, Priviledge.create.toString());
		    	priviledgeDao.assignPagePriviledge(developerId, pageId, Priviledge.read.toString());
		    	priviledgeDao.assignPagePriviledge(developerId, pageId, Priviledge.update.toString());
		   
		    }
		    
		    if (roleId == 4)
		    {
		    	priviledgeDao.assignPagePriviledge(developerId, pageId, Priviledge.create.toString());
		    	priviledgeDao.assignPagePriviledge(developerId, pageId, Priviledge.read.toString());
		    }
		    
		    if (roleId == 5)
		    {
		    	priviledgeDao.assignPagePriviledge(developerId, pageId, Priviledge.read.toString());
		    }
   
       }
     catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	
	
	//3.delete website role
	private final String DELETE_WEBSITE_ROLE = "DELETE FROM website_role WHERE developer_id=? "
			+ "AND web_id=? ANd role=?; ";
	public void deleteWebsiteRole(int developerId, int websiteId, int roleId)
	{
		 PreparedStatement preStatement = null;
		 PriviledgeDao priviledgeDao = PriviledgeDao.getInstance();
		 Connection conn = null;
			
			try {
				conn = MyConnection.getConnection(); 		
			    preStatement = conn.prepareStatement(DELETE_WEBSITE_ROLE);
			    preStatement.setInt(1,developerId);
			    preStatement.setInt(2,websiteId);
			    preStatement.setString(3,Role.getValueByKey(roleId));
		        preStatement.executeUpdate();
		        
			
	            preStatement.close();
			    conn.close();
			    
			    if (roleId == 1)
			    {
			    	priviledgeDao.deleteWebsitePriviledge(developerId, websiteId, Priviledge.create.toString());
			    	priviledgeDao.deleteWebsitePriviledge(developerId, websiteId, Priviledge.read.toString());
			    	priviledgeDao.deleteWebsitePriviledge(developerId, websiteId, Priviledge.update.toString());
			    	priviledgeDao.deleteWebsitePriviledge(developerId, websiteId, Priviledge.delete.toString());
			    }
			    
			    if (roleId == 2)
			    {
			    	priviledgeDao.deleteWebsitePriviledge(developerId, websiteId, Priviledge.create.toString());
			    	priviledgeDao.deleteWebsitePriviledge(developerId, websiteId, Priviledge.read.toString());
			    	priviledgeDao.deleteWebsitePriviledge(developerId, websiteId, Priviledge.update.toString());
			    	priviledgeDao.deleteWebsitePriviledge(developerId, websiteId, Priviledge.delete.toString());
			    }
			    
			    if (roleId == 3)
			    {
			    	priviledgeDao.deleteWebsitePriviledge(developerId, websiteId, Priviledge.create.toString());
			    	priviledgeDao.deleteWebsitePriviledge(developerId, websiteId, Priviledge.read.toString());
			    	priviledgeDao.deleteWebsitePriviledge(developerId, websiteId, Priviledge.update.toString());
			    }
			    
			    if (roleId == 4)
			    {
			    	priviledgeDao.deleteWebsitePriviledge(developerId, websiteId, Priviledge.read.toString());
			    	priviledgeDao.deleteWebsitePriviledge(developerId, websiteId, Priviledge.update.toString());
			    	
			    }
			    
			    if (roleId == 4)
			    {
			    	priviledgeDao.deleteWebsitePriviledge(developerId, websiteId, Priviledge.read.toString());
			    
			    }
			    
    
		} catch (ClassNotFoundException e) 
			{
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
	}
	
	
	//4.delete page role
	private final String DELETE_PAGE_ROLE = "DELETE FROM page_role WHERE developer_id=? "
			+ "AND page_id=? AND role=?;";
	public void deletePageRole(int developerId, int pageId, int roleId)
	{
		PreparedStatement preStatement = null;
		 PriviledgeDao priviledgeDao = PriviledgeDao.getInstance();
		 Connection conn = null;
			
			try {
				conn = MyConnection.getConnection(); 		
			    preStatement = conn.prepareStatement(DELETE_PAGE_ROLE);
			    preStatement.setInt(1,developerId);
			    preStatement.setInt(2,pageId);
			    preStatement.setString(3,Role.getValueByKey(roleId));
		        preStatement.executeUpdate();
		        
			
	            preStatement.close();
			    conn.close();
			    
			    if (roleId == 1)
			    {
			    	priviledgeDao.deletePagePriviledge(developerId, pageId, Priviledge.create.toString());
			    	priviledgeDao.deletePagePriviledge(developerId, pageId, Priviledge.read.toString());
			    	priviledgeDao.deletePagePriviledge(developerId, pageId, Priviledge.update.toString());
			    	priviledgeDao.deletePagePriviledge(developerId, pageId, Priviledge.delete.toString());
			    }
			    
			    if (roleId == 2)
			    {
			    	priviledgeDao.deletePagePriviledge(developerId, pageId, Priviledge.create.toString());
			    	priviledgeDao.deletePagePriviledge(developerId, pageId, Priviledge.read.toString());
			    	priviledgeDao.deletePagePriviledge(developerId, pageId, Priviledge.update.toString());
			    	priviledgeDao.deletePagePriviledge(developerId, pageId, Priviledge.delete.toString());
			    }
			    
			    if (roleId == 3)
			    {
			    	priviledgeDao.deletePagePriviledge(developerId, pageId, Priviledge.create.toString());
			    	priviledgeDao.deletePagePriviledge(developerId, pageId, Priviledge.read.toString());
			    	priviledgeDao.deletePagePriviledge(developerId, pageId, Priviledge.update.toString());
			    }
			    
			    if (roleId == 4)
			    {
			    	priviledgeDao.deletePagePriviledge(developerId, pageId, Priviledge.read.toString());
			    	priviledgeDao.deletePagePriviledge(developerId, pageId, Priviledge.update.toString());
			    	
			    }
			    
			    if (roleId == 4)
			    {
			    	priviledgeDao.deletePagePriviledge(developerId, pageId, Priviledge.read.toString());
			    
			    }
			    
   
		} catch (ClassNotFoundException e) 
			{
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
	}

}

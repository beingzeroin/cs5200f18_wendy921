package edu.northeastern.cs5200.daos;

import java.util.Collection;

import edu.northeastern.cs5200.models.Addresses;
import edu.northeastern.cs5200.models.Developer;

public interface AddressImpl {
		
	    public void createAddressForDeveloper(Developer developer);
	    
	    public Collection<Addresses> findPhoneForDeveloper(int developerId);
		
		//public int updateAddressForDeveloper(int developerId, Developer developer);
		
		public int deleteAddressForDeveloper(String username, boolean primary);

	}



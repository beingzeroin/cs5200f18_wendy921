package edu.northeastern.cs5200.daos;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import edu.northeastern.cs5200.MyConnection;

public class StoreProcedure {

	public static void getUnansweredQuestions ()
	 {Connection conn = null;
     ResultSet rs = null;
     CallableStatement cStmt = null;
     {
     try {
   	  conn = MyConnection.getConnection(); 
   	  cStmt = conn.prepareCall("{call get_unanswered_questions()}");
   	
   	  rs = cStmt.executeQuery();
   	  
   	  while (rs.next()) {
             String questionText = rs.getString(1);
             int maxAnswer = rs.getInt(2);
             System.out.println(questionText+ " " + maxAnswer);
	        	
	        }
   	  
   	  rs.close();
   	  cStmt.close();
   	  }
   	  
	       catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	       
	 finally {
		      try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 }
     }
     }
	
	
	////////////////
	
	public static void endorseUserForWeek (Date startDate, Date endDate) throws ParseException
	 {
		Connection conn = null;
       ResultSet rs = null;
       CallableStatement cStmt = null;
    
    try {
    	java.sql.Date start = new java.sql.Date(startDate.getTime());
    	java.sql.Date end = new java.sql.Date(endDate.getTime());
    	
    	//SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
    	//java.sql.Date start =new java.sql.Date(f.parse(startDate).getTime());
    	//java.sql.Date end =new java.sql.Date(f.parse(endDate).getTime());
    	
  	  conn = MyConnection.getConnection(); 
  	  cStmt = conn.prepareCall("{call endorsed_user_for_week(?,?)}");
  	  cStmt.setDate(1, start);
  	  cStmt.setDate(2, end);
	 
  	  cStmt.execute();
  	   rs = cStmt.getResultSet();
  	   

  	  
  	  while (rs.next()) {
            int userId = rs.getInt(1);
            String fullname = rs.getString(2);
            int endorsedUser = rs.getInt(3);
            
            System.out.println(userId+ " " + fullname+" "+endorsedUser);
	        	
	        }
  	  
  	  rs.close();
  	  cStmt.close();
  	  conn.close();
  	  }
  	  
	       catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	       
    }
    
 //////////////////////////////////////////////////////
	/**
	public static void main(String [] args) throws ParseException
	{
		getUnansweredQuestions ();

		SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");

		endorseUserForWeek (f.parse("2018-04-01"), f.parse("2018-04-10"));
	
	}
	**/
}
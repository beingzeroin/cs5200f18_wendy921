const mongoose = require('mongoose');
//import mongoose from 'mongoose';

const questionSchema = require('./question.schema.server');
module.exports = mongoose.model('QuestionModel', questionSchema);
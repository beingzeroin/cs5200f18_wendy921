const mongoose = require('mongoose');
//import mongoose from 'mongoose';

const answerSchema = require('./answer.schema.server');
module.exports = mongoose.model('AnswerModel', answerSchema);
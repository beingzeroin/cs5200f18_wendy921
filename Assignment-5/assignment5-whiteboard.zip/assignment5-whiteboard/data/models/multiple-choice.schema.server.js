const mongoose = require('mongoose');
//import mongoose from 'mongoose';

const MultipleChoiceSchema = mongoose.Schema({
    choices: String,
    correct: Number,
});
module.exports = MultipleChoiceSchema;

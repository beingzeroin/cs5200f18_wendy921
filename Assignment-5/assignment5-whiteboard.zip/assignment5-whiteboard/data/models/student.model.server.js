const mongoose = require('mongoose');
//import mongoose from 'mongoose';

const studentSchema = require('./student.schema.server');
module.exports = mongoose.model('StudentModel', studentSchema);
const mongoose = require('mongoose');
//import mongoose from 'mongoose';

const questionSchema = require('./question.schema.server');
const quizWidgetSchema = mongoose.Schema({
    wtype:  String,
    width: Number,
    height: Number,
    question: [{
        type: Number,
        ref: 'QuestionModel'
    }]
}, {collection: 'question-widgets'});

module.exports = quizWidgetSchema;
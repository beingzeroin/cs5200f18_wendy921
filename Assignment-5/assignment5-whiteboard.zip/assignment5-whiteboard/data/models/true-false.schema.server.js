const mongoose = require('mongoose');
//import mongoose from 'mongoose';

const TrueFalseSchema = mongoose.Schema({
    isTrue: Boolean
});
module.exports = TrueFalseSchema;
const mongoose = require('mongoose');
//import mongoose from 'mongoose';

const studentSchema = mongoose.Schema({
    _id: Number,
    firstName: String,
    lastName: String,
    username: String,
    password: String,
    gradYear: Number,
    scholarship: Number,
    // answer: [{
    //     type: Number,
    //     ref: 'AnswerModel'
    // }]
},
 {collection: 'students'});

module.exports = studentSchema;

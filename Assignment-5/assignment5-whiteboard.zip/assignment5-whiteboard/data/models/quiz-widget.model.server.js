const mongoose = require('mongoose');
//import mongoose from 'mongoose';

const quizWidgetSchema = require('./quiz-widget.schema.server');
module.exports = mongoose.model('QuizWidgetModel', quizWidgetSchema);
require('./db')();
const assert = require('assert');

const universityDao = require('./daos/university.dao.server');
const finderDao = require('./daos/finder.dao.server');



const assertEquals = (actual, expected) => {
    assert.strictEqual(actual, expected);
};



//1- uses DAO’s truncateDatabase() function to remove all the data from the database


//2- uses DAO’s populateDatabase() function to populate the database with test data


//3-- uses DAO to validate there are 2 students initially
testStudentsInitialCount = () =>
{
    return finderDao.findAllStudents()
        .then(students => {assertEquals(students.length, 2)})


};


//4-- uses DAO to validate there are 4 questions initially
testQuestionsInitialCount = () =>
{
    return finderDao.findAllQuestions()
        .then(questions => {assertEquals(questions.length, 4)})

};


//5-- uses DAO to validate there are 8 answers initially
testAnswersInitialCount = () =>
{
    return finderDao.findAllAnswers()
        .then(answers => {assertEquals(answers.length, 8)})

};


//6-- uses DAO to remove Bob’s answer for the multiple choice question “What does ORM stand for?” and validates
//the total number of amswers is 7 and Bob’s total number of answers is 3
testDeleteAnswer = () =>
{

    universityDao.deleteAnswer(890)
    .then(()  =>finderDao.findAllAnswers())
    .then(answers => {assertEquals(answers.length, 7)});
    finderDao.findAnswersByStudent(234)
        .then(BobAnswer => {assertEquals(BobAnswer.length, 3)})

};



//7-- uses DAO to remove true false question “Is the following schema valid?” and validates the total number
//of questions is 3
testDeleteQuestion = () =>
{
   universityDao.deleteQuestion(321)
       .then(() =>finderDao.findAllQuestions())
       .then(questions => {assertEquals(questions.length, 3)})

};


//8-- uses DAO to remove student Bob and validates the total number of students is 1
testDeleteStudent = () =>
{
    universityDao.deleteStudent(234)
        .then(() => finderDao.findAllStudents())
        .then(students => {assertEquals(students.length, 1)})


};

///////////////////////////////////////
universityDao.truncateDatabase()
    .then(() => universityDao.populateDatabase())
    .then(() => testStudentsInitialCount())
    .then( () => testQuestionsInitialCount())
    .then( () => testAnswersInitialCount())
    .then( () => testDeleteAnswer())
    .then( () => testDeleteQuestion())
    .then( () => testDeleteStudent());




const mongoose = require('mongoose');
//import mongoose from 'mongoose';

//const studentSchema = require('../models/student.schema.server');
const studentModel = require('../models/student.model.server');

//const answerSchema = require('../models/answer.schema.server');
const answerModel = require('../models/answer.model.server');

//const quizWidgetSchema = require('../models/quiz-widget.schema.server');
const quizWidgetModel = require('../models/quiz-widget.model.server');

//const questionSchema = require('../models/question.schema.server');
const questionModel = require('../models/question.model.server');


//(TWO) FINDER METHOD
//1- retrieves all students
findAllStudents = () =>
    studentModel.find();

//2- retrieves a single student document whose ID is id
findStudentById = studentId =>
    studentModel.find({_id: studentId});


//3- retrieves all questions
findAllQuestions = () =>
    questionModel.find();

//4- retrieves a single question document whose ID is id
findQuestionById =questionId =>
    questionModel.find({_id: questionId});

//5- retrieves all the answers
findAllAnswers = () =>
    answerModel.find();

//6- retrieves a single answer document whose ID is id
findAnswerById = answerId =>
    answerModel.find({_id: answerId});

//7- retrieves all the answers for a student whose ID is studentId
findAnswersByStudent = studentId =>
    answerModel.find({student: studentId});

//8- retrieves all the answers for a question whose ID is questionId
findAnswersByQuestion = questionId =>
    answerModel.find({question: questionId});

//9- find student by first name
findStudentByFirstName = studentFirstName =>
    studentModel.find({firstName: studentFirstName});

//////////////////////////////////
module.exports = {findAllStudents, findStudentById, findAllQuestions, findQuestionById, findAllAnswers,
    findAnswerById, findAnswersByStudent, findAnswersByQuestion, findStudentByFirstName};
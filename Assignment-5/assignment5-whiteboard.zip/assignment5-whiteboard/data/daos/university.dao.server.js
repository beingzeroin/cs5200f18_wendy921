
const mongoose = require('mongoose');
//import mongoose from 'mongoose';

//const studentSchema = require('../models/student.schema.server');
const studentModel = require('../models/student.model.server');

//const answerSchema = require('../models/answer.schema.server');
const answerModel = require('../models/answer.model.server');

//const quizWidgetSchema = require('../models/quiz-widget.schema.server');
const quizWidgetModel = require('../models/quiz-widget.model.server');

//const questionSchema = require('../models/question.schema.server');
const questionModel = require('../models/question.model.server');

const finderDao = require('./finder.dao.server');
//const universityDao = require('./university.dao.server');

//(ONE) API
//1- removes all the data from the database. Note that you might need to remove documents in a particular order
truncateDatabase = () =>
   {
      return  answerModel.deleteMany({})
           .then( () => studentModel.deleteMany({}))
           .then( () =>questionModel.deleteMany({}))
           .then( () =>quizWidgetModel.deleteMany({}));

   };

//2- populates the database with test data as described in a later section
populateDatabase = () =>
{
    //1-Create students
    var Alice = new studentModel({_id: 123, firstName: 'Alice', lastName: 'Wonderland', username: 'alice',
        password: 'alice', gradYear: 2020, scholarship: 15000});


    //
    var Bob = new studentModel({_id: 234, firstName: 'Bob', lastName: 'Hope', username: 'bob', password: 'bob',
        gradYear: 2021, scholarship: 12000});


    //2-Create questions
    //
    var question321 = new questionModel({_id: 321, question: 'Is the following schema valid?', points:10, questionType:'TRUE_FALSE',
        trueFalse: {isTrue: false}});


    //
   var question432 = new questionModel({_id: 432, question: 'DAO stands for Dynamic Access Object.', points:10, questionType:'TRUE_FALSE',
       trueFalse: {isTrue: false}});


    //
    var question543 = new questionModel({_id: 543, question: 'What does JPA stand for?', points:10, questionType:'MULTIPLE_CHOICE',
        multipleChoice:
            {
                choices: 'Java Persistence API,Java Persisted Application,JavaScript Persistence API,JSON Persistent ' +
                    'Associations',
                correct: 1}
    });


    //
    var question654 = new questionModel({_id: 654, question: 'What does ORM stand for?', points:10, questionType:'MULTIPLE_CHOICE',
        multipleChoice:
            {
                choices: 'Object Relational Model,Object Relative Markup,Object Reflexive Model,Object Relational ' +
                    'Mapping',
                correct: 4}
    });


    //3-Create Answer
    //Alice
    var answerA_Q321 = new answerModel({_id: 123, trueFalseAnswer: true});

    var answerA_Q432 = new answerModel({_id: 234, trueFalseAnswer: false});

    var answerA_Q543 = new answerModel({_id: 345, multipleChoiceAnswer: 1});

    var answerA_Q654 = new answerModel({_id: 456, multipleChoiceAnswer: 2});


    //Bob
    var answerB_Q321 = new answerModel({_id: 567, trueFalseAnswer: false});

    var answerB_Q432 = new answerModel({_id: 678, trueFalseAnswer: true});

    var answerB_Q543 = new answerModel({_id: 789, multipleChoiceAnswer: 3});

    var answerB_Q654 = new answerModel({_id: 890, multipleChoiceAnswer: 4});


    return createStudent(Alice)
        .then(() => createStudent(Bob))
        .then(() => createQuestion(question321))
        .then(() => createQuestion(question432))
        .then(() => createQuestion(question543))
        .then(() => createQuestion(question654))
        .then(() => createAnswer(answerA_Q321))
        .then(() => createAnswer(answerA_Q432))
        .then(() => createAnswer(answerA_Q543))
        .then(() => createAnswer(answerA_Q654))
        .then(() => createAnswer(answerB_Q321))
        .then(() => createAnswer(answerB_Q432))
        .then(() => createAnswer(answerB_Q543))
        .then(() => createAnswer(answerB_Q654))
        .then(() => answerQuestion(123,321, answerA_Q321))
        .then(() => answerQuestion(123,432, answerA_Q432))
        .then(() => answerQuestion(123,543, answerA_Q543))
        .then(() => answerQuestion(123,654, answerA_Q654))
        .then(() => answerQuestion(234,321, answerB_Q321))
        .then(() => answerQuestion(234,432, answerB_Q432))
        .then(() => answerQuestion(234,543, answerB_Q543))
        .then(() => answerQuestion(234,654, answerB_Q654))
};



//3- inserts a student document
createStudent =
    student =>
    {
         return studentModel.create(student);

    };

//4- removes student whose ID is id. Delete does not cascade
deleteStudent = studentId =>
    {
         return studentModel.deleteOne({_id: studentId});
    };

//5- inserts a question document
createQuestion =
        question =>
        {
            return questionModel.create(question)
        };

//6- removes question whose ID is id. Delete does not cascade
deleteQuestion = questionId =>
    {
        return questionModel.deleteOne({_id: questionId});
    };

//7- inserts an answer by student student for question question
answerQuestion = (studentId, questionId, answer) =>
   {
       // let student;
       // student = finderDao.findStudentById(studentId);
       // let question;
       // question = finderDao.findQuestionById(questionId);


       let answerId = answer._id;

       //answerModel.update({_id: answerId},{$set:{student: studentId, question: questionId}});

       let wherestr1 = {_id: answerId};
       let updatestr1 = {student: studentId, question: questionId};

       return answerModel.updateOne(wherestr1, updatestr1, function(err,res)
       {
           if(err){
               console.log("Error: " + err)
           }else {
               console.log("Success Res: " + res)
           }
       })
           // .then(() => {
           //     return answer.save(function (err, res) {
           //         if(err){
           //             console.log("Error: " + err)
           //         }else{
           //             console.log("Success Res: " + res)
           //         }
           //     });
           // })

           // .then(() => {
           //     return studentModel.updateOne({_id: studentId},{$push:{answer: answerId}})
           // })

           // .then(() => {
           //
           //     student = finderDao.findStudentById(studentId);
           //     return student;
           // })
           // .then( student => {
           //     return student.save().then(console.log).catch(console.log)
           //
           //     student.save(function (err, res) {
           //     if(err){
           //         console.log("Error: " + err)
           //     }else{
           //         console.log("Success Res: " + res)
           //     }
           // });
           // });

       ////////////////////////////////

       //     let wherestr2 = {_id: studentId};
       //     let updatestr2 = {answer: answerId};
       //
       // studentModel.update(wherestr2, updatestr2, function(err,res)
       // {
       //     if(err){
       //         console.log("Error: " + err)
       //     }else {
       //         console.log("Success Res: " + res)
       //     }
       // });


    };

//8- removes answer whose ID is id
deleteAnswer = answerId =>
   {
       return answerModel.deleteOne({_id: answerId});

   };

//9- create answer
createAnswer =
    answer =>
    {
        return answerModel.create(answer);
    };
/////////////////////////////////////////////////////////////////
module.exports = {truncateDatabase, populateDatabase, createStudent, deleteStudent, createQuestion,
    deleteQuestion, answerQuestion, deleteAnswer, createAnswer};
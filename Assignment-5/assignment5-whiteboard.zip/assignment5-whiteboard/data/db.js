
//import mongoose from 'mongoose';
module.exports = function () {
    const mongoose = require('mongoose');

    const databaseName = 'white-board';
    //var   connectionString = 'mongodb://localhost/';
    //connectionString += databaseName;
    //mongoose.connect(connectionString);
    mongoose.connect("mongodb://localhost:27017/"+databaseName, { useNewUrlParser: true });
};
